CLOCK-FREE SCALE COMPASS -- version 0.4
Research development for Monty, 14 October 2026

RESULT
An exact inverse-observation protocol for the inherited native two-generator
cell. Unknown common response gain cancels in a graph-aware trace ratio.
Three normalized invariant readings at known length/source-energy ratios
(1,1), (2,1), (1,2) recover positive q,p and predict the unused (2,2) setting.
Centered scale comparisons satisfy 1/sqrt(chi)-1 = X^2+Z^2 exactly.

START HERE
Clock_Free_Scale_Compass.pdf  -- nine-page proof note and scope
PROTOCOL.json               -- machine-readable observation contract
SCALE_COMPASS_RESULT.json   -- exact output and serialized proof certificates
verify_scale_compass.cjs    -- native computation and negative controls
verify.py                  -- Python 3.12 integrity and replay wrapper
parent/                    -- unchanged preceding physics-cubit packet

REPRODUCE
Requirements: Python 3.12 and Node.js. No npm installation is needed.
From the extracted packet folder:

    python3.12 verify.py

Expected status: PASS_NATIVE_SCALE_COMPASS
  10 symbolic certificates
  10 serialized replays
  610 exact checks
  10 negative controls
  25 positive parameter pairs
  16 centered circle cases

The 610 checks include compiler and replay assertions. They are not 610
independent experiments. Exact examples use synthetic model data.

The wrapper verifies the new and all inherited manifests, upstream source
blob pins and native engine hashes. It then invokes the new Node verifier
with --check, requiring byte-identical output to the recorded result. The
inherited computation is retained unchanged but not rerun by this wrapper;
its prior results and source are integrity-checked. The native engine files
are unchanged from the pinned source.

NATIVE ARITHMETIC CONTRACT
All mathematical arithmetic stays in the inherited native engine/compiler.
Python handles file hashes, JSON and process orchestration only. The new
exact rational-root adapter uses native F arithmetic and rejects non-rational
roots. There is no floating-point or external symbolic fallback. The general
positive-root formulas use the inherited real completion; arbitrary noisy
or irrational-input numerical decoding is not implemented in this packet.

OBSERVATION CONTRACT
- q,p and the comparison ratios s,t are positive.
- Independently known s and t act as q' = s*t*q, p' = t*p/s.
- The transport/observer contract and A,B,alpha,beta stay fixed over probes.
- Relative link weights are known; the bare and stationary effective root
  responses share one unknown common gain within each frame. Gains may
  differ between frames. Independent detector gains require another scale
  record.
- Each normalized reading requires two response traces and the graph
  normalizer, not just one raw detector number.
- Probes may depart from the exactly compatible two-cut sector; their
  defects are retained. Stationary elimination does not assert physical
  relaxation dynamics.
- The source-energy ratio must be independently calibrated. Changing a
  native source-vector amplitude alone does not establish an energy ratio.

MAIN FORMULAS
chi(q,p) = 16*q^2*p^2 / ((1+q^2)^2*(1+p^2)^2)
N = (sum_e 1/wbar_e)*(wbar_first+wbar_last)/4
chi = N * tr(K_eff)/tr(K_bare)
r = q/p; k = q*p
Y(s,t) = 4/sqrt(chi(s,t))
       = r*s^2 + 1/(r*s^2) + k*t^2 + 1/(k*t^2)
dL = (Y(2,1)-Y(1,1))/3; dE = (Y(1,2)-Y(1,1))/3
r = (dL+sqrt(dL^2+1))/2; k = (dE+sqrt(dE^2+1))/2
q = sqrt(r*k); p = sqrt(k/r)
Required consistency: Y(1,1) = r+1/r+k+1/k
Held out: chi(2,2) = 16/(Y(2,1)+Y(1,2)-Y(1,1))^2
Balance: s_star^2 = 1/r; t_star^2 = 1/k
sigma = s/s_star; tau = t/t_star
X = (sigma-1/sigma)/2; Z = (tau-1/tau)/2
Phi = X^2+Z^2; chi = 1/(1+Phi)^2

NOTATION NOTE
The code/result use Y as the second coordinate within centred_circle_cases
and the local circle formula; the PDF calls that coordinate Z to distinguish
it from the inverse response Y(s,t). In result fields root_resolvent and
characteristic, t is the resolvent shift called z in the PDF. These are
local notational aliases, not extra physical parameters.

EVIDENCE BOUNDARY
The 10 compiler certificates cover six polynomial scale identities and four
first-order jet identities. The graph normalization, positivity/uniqueness,
reconstruction and full rooted-resolvent statements also have written proofs
in the PDF; finite exact matrix checks do not certify an arbitrary graph by
themselves. The auxiliary relation j^2=0 is a declared first-order quotient,
not a time variable or an operator identity imposed on the physical cell.

This packet does not derive a physical gravitational field equation, fix
alpha=beta=1, predict empirical constants or prove the global physical
adapter from four measurements. The explicit absolute calibration family
and a four-frame-passing counterexample are retained in negative controls.
The exact circle is in a plane of centered comparisons, not established
physical spacetime geometry.

BUILD THE NOTE
Requires a TeX installation with the packages listed in the .tex source:

    pdflatex Clock_Free_Scale_Compass.tex
    pdflatex Clock_Free_Scale_Compass.tex

Rebuilding a PDF may change its bytes; verification checks the delivered
PDF against the delivered manifest. Preserve the original packet if running
integrity verification after a local rebuild.

SOURCE CONTINUITY
Recognition-Kernel-Framework main pin:
e8e3089745bf7dc0532d01c62a5f660f5658c6f0
Canonical native home: operator_foundation/
Earlier source/version pins and their provenance are retained in parent/.

The new result is the inverse-observation protocol and comparison geometry.
The native generators, cut selection, loop formula, series response and
physical dictionary are inherited and are not presented as new derivations.
