"""Python 3.12 entry point; all mathematical arithmetic stays in the native engine."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys

if sys.version_info[:2] != (3, 12):
    raise SystemExit('This packet requires Python 3.12.')
root = Path(__file__).resolve().parent
manifest = root / 'MANIFEST.json'
if manifest.exists():
    for item in json.loads(manifest.read_text())['files']:
        assert hashlib.sha256((root/item['path']).read_bytes()).hexdigest() == item['sha256'], item['path']
subprocess.run(['node', str(root/'verify_cell.cjs'), '--check'], check=True, cwd=root)
print('Source integrity and exact native cell replay passed under Python 3.12.')
