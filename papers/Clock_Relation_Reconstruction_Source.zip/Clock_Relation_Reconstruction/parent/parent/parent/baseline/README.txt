CLOCK-FREE NATIVE LATTICE — VERSION 0.1
Research development for Monty Dabas | 2026-10-14

RESULT
A declared dimensionless four-node comparison cell built with the canonical
Recognition Kernel native arithmetic and proof compiler. For unit link
weights, exact stationary elimination gives K_eff = chi I, where
chi(q) = 16 q^4 / (1 + q^2)^4.
At q = 1/2, chi = 256/625 and the source response coefficient is 625/256.

SCOPE
This is a finite structural construction and conditional theorem packet,
not an established physical quantum-gravity theory. The real central
parameter q, positive native record pairing, simple bipartite graph class,
quadratic transported-difference cost and source coupling are declared inputs.
No physical time, lattice spacing, Newton constant or mass law is derived.

MINIMUM STATEMENTS
- Four vertices and four links: connected simple bipartite graph with a cycle.
- Module rank two: a fixed pair of noncommuting endomorphisms over the
  commutative native cut-complex field.
- One additional cut-complex linear coordinate: reconstruction of the full
  local rank-two record from the specified rank-one observer.
These are different minima. None is a claim of the smallest physical spacetime,
one bit of memory, or one physical qubit.

REPRODUCE
Use Python 3.12 and Node.js. Tested: Python 3.12.14; Node 24.19.0.
No third-party Python or Node packages are needed for the mathematics.
From this folder:
    python3.12 verify.py
The wrapper checks MANIFEST.json if present, checks the canonical dependency
pins, reruns exact native arithmetic, serializes and replays six symbolic
certificates, and compares CELL_RESULT.json byte for byte. It does not rewrite
the recorded result. For intentional regeneration after a reviewed edit:
    node verify_cell.cjs

CONTENTS
Clock_Free_Native_Lattice.tex : full mathematical note source
output/pdf/Clock_Free_Native_Lattice.pdf : rendered note
verify_cell.cjs : finite model, proof certificates, exact checks and controls
verify.py : Python 3.12 replay and integrity wrapper
CELL_RESULT.json : saved exact results and replayable proof certificates
native/core/ : two unchanged canonical engine dependencies
sources/ : upstream source snapshots used in the audit
LOCAL_SOURCE_PINS.json : canonical dependency and prior snapshot SHA-256 pins
REMOTE_SOURCE_PINS.json : additional exact Git blob pins and source URLs
SOURCE_AUDIT.txt : provenance and contribution boundaries
MANIFEST.json : all packet-file SHA-256 values, excluding the manifest itself

VERIFY RESULTS
6 symbolic identities; 6 serialized certificate replays.
15 rational parameter cases; 257 exact passing checks.
6 negative controls; 75 labelled simple graphs through four vertices.
The polynomial presentation has checked critical-pair confluence and a
descending dagger. This is custom native certificate replay, not independent
formal-assistant certification or physical experimental validation.
The entire upstream test suite was not rerun; dependencies are unmodified.

PDF BUILD
The PDF source uses LaTeX (pdflatex), standard AMS, geometry, lmodern, TikZ,
hyperref, tabularx, fancyhdr and microtype packages. Run pdflatex twice with
output directory output/pdf. Generated logs and raster QA pages are not
included in this packet.

TIME EXTENSION
Operation order and returning memory are already retained. An additive
history budget can be attached later, but a positive budget for an inverse
pair cannot be collapsed with its transport to the empty history. Physical
clock calibration and spacetime signature remain further conditions.

No upstream repository was changed. Read SOURCE_AUDIT.txt before copying
this development into a theorem register.
