'use strict';
// Clock-free, dimensionless finite cell. Uses only the pinned native engine.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const assert = require('node:assert/strict');
const root = __dirname;
for (const pin of JSON.parse(fs.readFileSync(path.join(root, 'LOCAL_SOURCE_PINS.json'))).records) {
  assert.equal(crypto.createHash('sha256').update(fs.readFileSync(path.join(root, pin.local_path))).digest('hex'), pin.sha256, 'Source pin mismatch: ' + pin.local_path);
}
const N = require('./native/core/native_operator.cjs');
const M = require('./native/core/paninian_operator.cjs');
const {F,Cut,IOTA} = N;
const f = x => F.of(x);
const I = N.identity(2), R = N.matrix([[0,-1],[1,0]]), K = N.matrix([[0,1],[1,0]]);
const P = N.scale(N.add(I,K),'1/2'), Q = N.sub(I,P);
const E = N.matrix([['1/2','1/2']]), B = N.matrix([['1/2','-1/2']]);
const checks = [], negatives = [];
function check(name, condition, detail={}) { assert.ok(condition, name); checks.push({name,passed:true,...detail}); }
function control(name, condition, detail={}) { assert.ok(condition, name); negatives.push({name,rejected_false_claim:true,...detail}); }
const eq = N.equal;
const mul = (...xs) => xs.reduce((a,b)=>N.mul(a,b));
const dagger = N.dagger;
function cell(q) {
  q=f(q); const d=f(1).add(q.pow(2));
  const a=f(1).sub(q.pow(2)).div(d), b=q.mul(2).div(d);
  const U=N.add(N.scale(I,a),N.scale(R,b));
  const V=N.add(N.scale(I,a),N.scale(K,new Cut(0,b)));
  const C=mul(dagger(V),dagger(U),V,U);
  return {q,a,b,U,V,C,chi:b.pow(4)};
}
function incidence(edges, weights=edges.map(()=>f(1))) {
  const n=edges.length, D=N.zeros(2*n);
  for(let e=0;e<n;e++) {
    const t=(e+1)%n;
    for(let i=0;i<2;i++)for(let j=0;j<2;j++) {
      D[2*e+i][2*e+j]=edges[e][i][j].neg();
      D[2*e+i][2*t+j]=I[i][j];
    }
  }
  const WD=D.map((row,i)=>row.map(x=>x.mul(weights[Math.floor(i/2)])));
  return {D,H:mul(dagger(D),WD)};
}
function block(A,r0,r1,c0,c1) { return A.slice(r0,r1).map(r=>r.slice(c0,c1)); }
function schurRoot(H) {
  const n=H.length, A=block(H,0,2,0,2), X=block(H,0,2,2,n), Z=block(H,2,n,2,n);
  return N.sub(A,mul(X,N.inverse(Z),dagger(X)));
}
function leastCostPath(edges,weights,base) {
  const prefixes=[I]; for(const T of edges) prefixes.push(mul(T,prefixes.at(-1)));
  const hol=prefixes.at(-1), end=mul(dagger(hol),base);
  const resistance=weights.reduce((s,w)=>s.add(f(1).div(w)),f(0));
  let position=f(0); const states=[base];
  for(let k=1;k<edges.length;k++) {
    position=position.add(f(1).div(weights[k-1]));
    const t=position.div(resistance);
    states.push(mul(prefixes[k],N.add(N.scale(base,f(1).sub(t)),N.scale(end,t))));
  }
  let cost=f(0);
  for(let k=0;k<edges.length;k++) {
    const residual=N.sub(states[(k+1)%states.length],mul(edges[k],states[k]));
    cost=cost.add(N.energy(residual).mul(weights[k]).div(2));
  }
  return {states,cost,resistance,holonomy:hol};
}

// Symbolic q is central and self-dagger. These are polynomial certificates,
// not numerical samples and not a claim that q is selected by nature.
const S = new M.Presentation({tokens:['R','K','q'],rules:[
  {id:'RR',lhs:['R','R'],rhs:[[[],-1]],source:'RKF N01 / T48'},
  {id:'KK',lhs:['K','K'],rhs:[[[],1]],source:'RKF N01 / T48'},
  {id:'KR',lhs:['K','R'],rhs:[[['R','K'],-1]],source:'RKF N01 / T48'},
  {id:'qR',lhs:['q','R'],rhs:[[['R','q'],1]],source:'Declared central parameter q'},
  {id:'qK',lhs:['q','K'],rhs:[[['K','q'],1]],source:'Declared central parameter q'}
]});
const sr=S.word(['R']), sk=S.word(['K']), sq=S.word(['q']), one=S.one();
const starMap={R:sr.scale(-1),K:sk,q:sq};
const audit=S.audit();
check('symbolic_confluence',audit.status==='CONFLUENT_BY_CHECKED_DIAMONDS',{critical_pairs:audit.criticalPairs});
check('symbolic_dagger',M.daggerGate(S,starMap).status==='DAGGER_DESCENDS');
const nf=x=>S.reduce(x).normal;
const pow=(x,n)=>{let y=one;for(let k=0;k<n;k++)y=nf(y.times(x));return y;};
const q2=pow(sq,2), aa=one.minus(q2), bb=sq.scale(2), dd=one.plus(q2);
const Un=aa.plus(bb.times(sr)), Vn=aa.plus(bb.times(sk).scale(IOTA));
const Ud=M.star(Un,starMap), Vd=M.star(Vn,starMap);
const certs=[];
function theorem(name,lhs,rhs) {
  const proof=M.proveEquality(lhs,rhs);
  check(name,proof.status==='EQUAL_IN_DECLARED_QUOTIENT');
  const certificate=JSON.parse(JSON.stringify(proof.certificate));
  check(name+'_replay',S.replay(certificate)===true);
  certs.push({name,certificate});
}
theorem('circle_polynomial',pow(aa,2).plus(pow(bb,2)),pow(dd,2));
theorem('U_inverse_polynomial',Ud.times(Un),pow(dd,2));
theorem('V_inverse_polynomial',Vd.times(Vn),pow(dd,2));
const diff=Vn.times(Un).minus(Un.times(Vn));
theorem('ordered_path_residue',diff,sr.times(sk).times(q2).scale(new Cut(0,-8)));
const hn=Vd.times(Ud).times(Vn).times(Un);
// Independently stated closed expression from Proposition 2, denominator d^4.
const hnClosed=pow(dd,4).minus(pow(bb,4).scale(2))
  .plus(aa.times(pow(bb,3)).times(sr).scale(2))
  .plus(aa.times(pow(bb,3)).times(sk).scale(new Cut(0,-2)))
  .plus(pow(aa,2).times(pow(bb,2)).times(sr).times(sk).scale(new Cut(0,-2)));
const hnNormal=nf(hnClosed);
theorem('holonomy_normal_form',hn,hnNormal);
const zn=hnNormal.minus(pow(dd,4));
theorem('holonomy_defect_polynomial',M.star(zn,starMap).times(zn),pow(sq,4).times(pow(dd,4)).scale(64));
control('wrong_commutator_sign',M.proveEquality(diff,sr.times(sk).times(q2).scale(new Cut(0,8))).status==='DISTINCT_IN_DECLARED_QUOTIENT');

const parameters=['-3','-2','-1','-2/3','-1/2','-1/3','-1/10','0','1/10','1/3','1/2','2/3','1','2','3'];
const records=[];
for(const value of parameters) {
  const z=cell(value), {q,a,b,U,V,C,chi}=z;
  check('unitary_links:'+value,eq(mul(dagger(U),U),I)&&eq(mul(dagger(V),V),I));
  check('Cayley_agreement:'+value,eq(U,N.cayley(R,q))&&eq(V,N.cayley(N.scale(K,IOTA),q)));
  check('circle_relation:'+value,a.pow(2).add(b.pow(2)).eq(1));
  const delta=N.sub(mul(V,U),mul(U,V));
  check('exact_order_residue:'+value,eq(delta,N.scale(mul(R,K),new Cut(0,b.pow(2).mul(-2)))));
  check('unitary_holonomy:'+value,eq(mul(dagger(C),C),I));
  const defect=N.sub(C,I), gram=mul(dagger(defect),defect);
  check('defect_scalar_identity:'+value,eq(gram,N.scale(I,chi.mul(4))));
  check('invariant_normalization:'+value,N.energy(defect).div(8).eq(chi)&&f(0).le(chi)&&chi.le(1));
  check('norm_closure:'+value,eq(N.sub(mul(dagger(U),I,U),I),N.zeros(2)));
  check('returning_memory:'+value,eq(mul(P,dagger(U),Q,U,P),N.scale(P,b.pow(2))));
  check('reset_response:'+value,eq(mul(P,dagger(U),P,U,P),N.scale(P,a.pow(2))));
  const edges=[U,V,dagger(U),dagger(V)], {D,H}=incidence(edges);
  const effective=schurRoot(H);
  check('Schur_loop_cost:'+value,eq(effective,N.scale(I,chi)));
  const base=N.matrix([[1],[new Cut('1/3','1/2')]]);
  const path=leastCostPath(edges,edges.map(()=>f(1)),base);
  check('interpolation_minimum_cost:'+value,path.cost.eq(chi.mul(N.energy(base)).div(2)));
  const full=path.states.flat();
  const residual=mul(H,full);
  check('interior_stationarity:'+value,N.isZero(residual.slice(2))&&eq(residual.slice(0,2),N.scale(base,chi)));
  if(!q.zero()) {
    check('full_positive_model_invertible:'+value,N.rank(H)===8);
    const source=N.matrix([[1],[0],...[0,0,0,0,0,0].map(()=>[0])]);
    const response=mul(N.inverse(H),source);
    check('source_response:'+value,eq(response.slice(0,2),N.matrix([[f(1).div(chi)],[0]])));
    check('minimum_future_memory:'+value,N.rowClosure(E,[U,V,dagger(U),dagger(V)]).extra===1);
  } else {
    check('flat_zero_modes',N.rank(H)===6&&N.isZero(effective));
  }
  records.push({q,a,b,chi,holonomy:C,defect_gram:gram,effective_cost_operator:effective,rank_H:N.rank(H),minimum_fixed_root_cost:path.cost});
}

const sample=cell('1/2'), edges=[sample.U,sample.V,dagger(sample.U),dagger(sample.V)];
const gauges=[cell('1/3').U,cell('-2/3').V,R,mul(cell('2').V,cell('1/4').U)];
const changedEdges=edges.map((T,k)=>mul(gauges[(k+1)%4],T,dagger(gauges[k])));
const changedHol=changedEdges.reduce((a,T)=>mul(T,a),I);
check('local_frame_covariance',eq(changedHol,mul(gauges[0],sample.C,dagger(gauges[0]))));
check('local_frame_invariant',N.energy(N.sub(changedHol,I)).div(8).eq(sample.chi));
check('observer_decoder',eq(N.inverse(N.matrix([E[0],B[0]])),N.matrix([[1,1],[1,-1]])));
const hidden=N.matrix([[1],[-1]]);
control('endpoint_only_recovery',N.isZero(mul(E,hidden))&&!N.isZero(mul(E,sample.U,hidden)));
control('reset_erases_return',!eq(mul(P,dagger(sample.U),P,sample.U,P),P));
control('equal_invariant_not_equal_transport',cell('1/2').chi.eq(cell('2').chi)&&!eq(cell('1/2').U,cell('2').U));
const central=cell(1).C, rho=N.matrix([[1,0],[0,0]]);
control('central_phase_is_not_quantum_state_change',eq(central,N.scale(I,-1))&&eq(mul(central,rho,dagger(central)),rho));

const base=N.matrix([[1],[0]]);
const original=leastCostPath(edges,[1,1,1,1].map(f),base);
const refinedEdges=edges.flatMap(T=>[I,T]);
const refined=leastCostPath(refinedEdges,refinedEdges.map(()=>f(2)),base);
const unscaled=leastCostPath(refinedEdges,refinedEdges.map(()=>f(1)),base);
check('weighted_refinement',eq(refined.holonomy,original.holonomy)&&refined.cost.eq(original.cost)&&refined.resistance.eq(4));
control('unweighted_refinement_changes_cost',unscaled.cost.eq(original.cost.div(2))&&!unscaled.cost.eq(original.cost));

// Exhaust all labelled simple graphs through four vertices: combinatorial control.
const graphCounts=[];
for(let n=1;n<=4;n++) {
  const pairs=[];for(let i=0;i<n;i++)for(let j=i+1;j<n;j++)pairs.push([i,j]);
  let connectedBipartite=0, cyclicBipartite=0;
  for(let mask=0;mask<(1<<pairs.length);mask++) {
    const adj=Array.from({length:n},()=>[]);let e=0;
    pairs.forEach(([i,j],k)=>{if(mask&(1<<k)){adj[i].push(j);adj[j].push(i);e++;}});
    const color=Array(n).fill(-1), todo=[0];color[0]=0;let bipartite=true;
    for(let k=0;k<todo.length;k++)for(const v of adj[todo[k]]) {
      if(color[v]===-1){color[v]=1-color[todo[k]];todo.push(v);}
      else if(color[v]===color[todo[k]])bipartite=false;
    }
    if(todo.length===n&&bipartite){connectedBipartite++;if(e>=n)cyclicBipartite++;}
  }
  graphCounts.push({vertices:n,graphs_enumerated:1<<pairs.length,connected_bipartite:connectedBipartite,cyclic_bipartite:cyclicBipartite});
}
check('conditional_graph_minimum',graphCounts.slice(0,3).every(x=>x.cyclic_bipartite===0)&&graphCounts[3].cyclic_bipartite===3);

const output={schema:'clock-free-native-cell.v1',status:'PASS_DECLARED_NATIVE_CELL',scope:'Dimensionless finite model with declared connection and quadratic cost; physical quantum gravity is not established.',checks,negative_controls:negatives,symbolic:{presentation:S.spec(),audit,certificates:certs},finite_cases:records,graph_enumeration:graphCounts,benchmark:records.find(x=>x.q.eq('1/2')),refinement:{original_cost:original.cost,preserved_cost:refined.cost,unweighted_cost:unscaled.cost},summary:{symbolic_identities:certs.length,serialized_proof_replays:certs.length,parameter_cases:records.length,checks:checks.length,negative_controls:negatives.length,simple_graphs:graphCounts.reduce((a,x)=>a+x.graphs_enumerated,0),minimum_vertices_in_declared_class:4,minimum_links_in_declared_class:4,minimum_noncommuting_module_rank:2,minimum_added_cut_complex_memory:1}};
const serialized=JSON.stringify(output,null,2)+'\n';
const out=path.join(root,'CELL_RESULT.json');
if(process.argv.includes('--check')) assert.equal(fs.readFileSync(out,'utf8'),serialized,'Saved result differs from exact replay');
else fs.writeFileSync(out,serialized);
console.log(JSON.stringify({status:output.status,mode:process.argv.includes('--check')?'read-only replay':'generate',...output.summary,benchmark_chi:output.benchmark.chi,benchmark_holonomy:output.benchmark.holonomy},null,2));
