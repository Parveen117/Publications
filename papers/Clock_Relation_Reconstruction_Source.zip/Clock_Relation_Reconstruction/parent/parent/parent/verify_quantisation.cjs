'use strict';
// Native exact arithmetic and certificates: unchanged canonical dependencies.
const fs=require('node:fs'), path=require('node:path'), crypto=require('node:crypto');
const assert=require('node:assert/strict'), root=__dirname;
for(const pin of JSON.parse(fs.readFileSync(path.join(root,'baseline/LOCAL_SOURCE_PINS.json'))).records) {
  assert.equal(crypto.createHash('sha256').update(fs.readFileSync(path.join(root,'baseline',pin.local_path))).digest('hex'),pin.sha256,pin.local_path);
}
const N=require('./baseline/native/core/native_operator.cjs');
const M=require('./baseline/native/core/paninian_operator.cjs');
const {F,Cut,IOTA}=N, f=x=>F.of(x), I=N.identity(2);
const R=N.matrix([[0,-1],[1,0]]), K=N.matrix([[0,1],[1,0]]);
const Jcut=N.scale(R,IOTA);
const P=N.scale(N.add(I,K),'1/2'), P2=N.scale(N.add(I,Jcut),'1/2');
const E=N.matrix([['1/2','1/2']]);
const E2=N.matrix([['1/2',new Cut(0,'-1/2')]]);
const mm=(...xs)=>xs.reduce((a,b)=>N.mul(a,b)), adj=N.dagger, eq=N.equal;
const checks=[], controls=[], certificates=[], presentations=[];
const check=(name,ok,detail={})=>{assert.ok(ok,name);checks.push({name,passed:true,...detail});};
const control=(name,ok,detail={})=>{assert.ok(ok,name);controls.push({name,false_inference_rejected:true,...detail});};
const trace=A=>A.reduce((z,row,i)=>z.add(row[i]),Cut.of(0));
const det2=A=>A[0][0].mul(A[1][1]).sub(A[0][1].mul(A[1][0]));
function polynomial(A,coeffs) {
  const id=N.identity(A.length);let out=N.zeros(A.length);
  for(const c of coeffs)out=N.add(mm(out,A),N.scale(id,c));
  return out;
}
function cell(q,p) {
  q=f(q);p=f(p);
  const dq=f(1).add(q.pow(2)),dp=f(1).add(p.pow(2));
  const a=f(1).sub(q.pow(2)).div(dq),b=q.mul(2).div(dq);
  const c=f(1).sub(p.pow(2)).div(dp),d=p.mul(2).div(dp);
  const U=N.cayley(R,q),V=N.cayley(N.scale(K,IOTA),p);
  const H=mm(adj(V),adj(U),V,U),chi=b.pow(2).mul(d.pow(2));
  return {q,p,a,b,c,d,U,V,H,chi,eta1:chi.mul(a.pow(2)).mul(4),eta2:chi.mul(c.pow(2)).mul(4)};
}
function shift(edges) {
  const n=edges.length, S=N.zeros(2*n);
  edges.forEach((T,k)=>{for(let i=0;i<2;i++)for(let j=0;j<2;j++)S[2*((k+1)%n)+i][2*k+j]=T[i][j];});
  return S;
}
function model(z) {
  const edges=[z.U,z.V,adj(z.U),adj(z.V)],S=shift(edges),I8=N.identity(8);
  const L=N.sub(N.scale(I8,2),N.add(S,adj(S)));
  const Gamma=N.zeros(8);for(let k=0;k<8;k++)Gamma[k][k]=Cut.of(Math.floor(k/2)%2?-1:1);
  return {edges,S,L,Gamma,I8};
}
function schurRoot(A) {
  const n=A.length, block=(r0,r1,c0,c1)=>A.slice(r0,r1).map(r=>r.slice(c0,c1));
  const X=block(0,2,2,n);
  return N.sub(block(0,2,0,2),mm(X,N.inverse(block(2,n,2,n)),adj(X)));
}
function proof(S,name,lhs,rhs) {
  const p=M.proveEquality(lhs,rhs);check(name,p.status==='EQUAL_IN_DECLARED_QUOTIENT');
  const cert=JSON.parse(JSON.stringify(p.certificate));
  check(name+':serialized_replay',S.replay(cert)===true);
  certificates.push({name,certificate:cert});
}
function admit(S,name,starMap) {
  const audit=S.audit(),gate=M.daggerGate(S,starMap);
  check(name+':critical_pairs',audit.status==='CONFLUENT_BY_CHECKED_DIAMONDS');
  check(name+':dagger',gate.status==='DAGGER_DESCENDS');
  presentations.push({name,spec:S.spec(),audit,dagger_status:gate.status});
}

// Two independent native Cayley parameters q,p: no equal-parameter shortcut.
const A=new M.Presentation({tokens:['R','K','q','p'],rules:[
  {id:'RR',lhs:['R','R'],rhs:[[[],-1]]},{id:'KK',lhs:['K','K'],rhs:[[[],1]]},
  {id:'KR',lhs:['K','R'],rhs:[[['R','K'],-1]]},
  {id:'qR',lhs:['q','R'],rhs:[[['R','q'],1]]},{id:'qK',lhs:['q','K'],rhs:[[['K','q'],1]]},
  {id:'pR',lhs:['p','R'],rhs:[[['R','p'],1]]},{id:'pK',lhs:['p','K'],rhs:[[['K','p'],1]]},
  {id:'pq',lhs:['p','q'],rhs:[[['q','p'],1]]}
].map(r=>({...r,source:['RR','KK','KR'].includes(r.id)?'RKF N01 / T48':'Declared independent central parameters q,p'}))});
const ar=A.word(['R']),ak=A.word(['K']),aq=A.word(['q']),ap=A.word(['p']),one=A.one();
const amap={R:ar.scale(-1),K:ak,q:aq,p:ap};admit(A,'two_parameter_EMK',amap);
const nf=x=>A.reduce(x).normal;
const pw=(x,n)=>{let y=one;for(let i=0;i<n;i++)y=nf(y.times(x));return y;};
const qsq=pw(aq,2),psq=pw(ap,2),dq=one.plus(qsq),dp=one.plus(psq);
const aa=one.minus(qsq),bb=aq.scale(2),cc=one.minus(psq),dd=ap.scale(2);
const un=aa.plus(bb.times(ar)),vn=cc.plus(dd.times(ak).scale(IOTA));
const hn=M.star(vn,amap).times(M.star(un,amap)).times(vn).times(un);
const den=pw(dq,2).times(pw(dp,2));
const hc=nf(den.minus(pw(bb,2).times(pw(dd,2)).scale(2))
  .plus(aa.times(bb).times(pw(dd,2)).times(ar).scale(2))
  .plus(pw(bb,2).times(cc).times(dd).times(ak).scale(new Cut(0,-2)))
  .plus(aa.times(bb).times(cc).times(dd).times(ar).times(ak).scale(new Cut(0,-2))));
proof(A,'two_parameter_holonomy',hn,hc);
const defect=hc.minus(den);
proof(A,'two_parameter_loop_defect',M.star(defect,amap).times(defect),pw(bb,2).times(pw(dd,2)).times(den).scale(4));
const cuts=[one.plus(ak).scale('1/2'),one.plus(ar.scale(IOTA)).scale('1/2')];
const rhsScalars=[
  pw(aa,2).times(pw(bb,2)).times(pw(dd,2)).times(pw(dp,2)).scale(4),
  pw(bb,2).times(pw(cc,2)).times(pw(dd,2)).times(pw(dq,2)).scale(4)
];
cuts.forEach((Pj,k)=>{const leak=nf(one.minus(Pj).times(hc).times(Pj));proof(A,'cut_leakage_polynomial_'+(k+1),M.star(leak,amap).times(leak),rhsScalars[k].times(Pj));});

// The cyclic identity precedes any spectral chart or physical time.
const C=new M.Presentation({tokens:['S','T'],rules:[
 {id:'ST',lhs:['S','T'],rhs:[[[],1]]},{id:'TS',lhs:['T','S'],rhs:[[[],1]]}
].map(r=>({...r,source:'Unitary typed cyclic shift inverse contract'}))});
const s=C.word(['S']),t=C.word(['T']),co=C.one(),cstar={S:t,T:s};admit(C,'unitary_shift',cstar);
const cp=(x,n)=>{let y=co;for(let k=0;k<n;k++)y=C.reduce(y.times(x)).normal;return y;};
const sum=s.plus(t);
proof(C,'cyclic_fourth_power_identity',cp(sum,4).minus(cp(sum,2).scale(4)).plus(co.scale(2)),cp(s,4).plus(cp(t,4)));

// H=-I implies S^4=-I; dagger S = -S^3 in this quotient.
const B=new M.Presentation({tokens:['S','z'],rules:[
 {id:'S4',lhs:['S','S','S','S'],rhs:[[[],-1]]},
 {id:'zS',lhs:['z','S'],rhs:[[['S','z'],1]]}
].map(r=>({...r,source:r.id==='S4'?'Two-cut-compatible nontrivial loop sector H=-I on the four-link cell':'Declared central spectral variable z'}))});
const bs=B.word(['S']),bz=B.word(['z']),bo=B.one();
const bp=(x,n)=>{let y=bo;for(let k=0;k<n;k++)y=B.reduce(y.times(x)).normal;return y;};
const bstar={S:bp(bs,3).scale(-1),z:bz};admit(B,'central_minus_cycle',bstar);
const centred=bp(bs,3).minus(bs),op=bo.scale(2).plus(centred);
proof(B,'centred_operator_self_dagger',M.star(centred,bstar),centred);
proof(B,'centred_operator_square',bp(centred,2),bo.scale(2));
proof(B,'two_level_minimal_polynomial',bp(op,2).minus(op.scale(4)).plus(bo.scale(2)),B.zero());
proof(B,'exact_resolvent_identity',op.plus(bz).times(bz.plus(bo.scale(4)).minus(op)),bp(bz,2).plus(bz.scale(4)).plus(bo.scale(2)));
const ratioOperator=bo.scale(3).plus(centred.scale(2));
proof(B,'scale_free_level_ratio',bp(ratioOperator,2).minus(ratioOperator.scale(6)).plus(bo),B.zero());

const parameters=['-1','-1/2','0','1/2','1'],cases=[];
for(const q of parameters)for(const p of parameters) {
  const z=cell(q,p),{H,chi}=z,{S,L,Gamma,I8}=model(z),tag=q+','+p;
  check('links_and_loop_unitary:'+tag,eq(mm(adj(z.U),z.U),I)&&eq(mm(adj(z.V),z.V),I)&&eq(mm(adj(H),H),I));
  check('commutator_determinant_one:'+tag,det2(H).eq(1));
  [P,P2].forEach((Pj,j)=>{const leak=mm(N.sub(I,Pj),H,Pj);check('cut_leakage_'+j+':'+tag,eq(mm(adj(leak),leak),N.scale(Pj,j?z.eta2:z.eta1)));});
  const both=N.isZero(N.commutator(H,P))&&N.isZero(N.commutator(H,P2));
  check('two_cut_sector_selection:'+tag,both===(chi.zero()||chi.eq(1)));
  check('retained_shift_unitary:'+tag,eq(mm(adj(S),S),I8));
  check('cost_is_gram:'+tag,eq(L,mm(adj(N.sub(I8,S)),N.sub(I8,S))));
  check('bipartite_cut:'+tag,eq(mm(Gamma,L,Gamma),N.sub(N.scale(I8,4),L)));
  check('full_loop_scalar_trace:'+tag,eq(N.add(N.power(S,4),N.power(adj(S),4)),N.scale(I8,f(2).sub(chi.mul(4)))));
  check('general_spectral_polynomial:'+tag,N.isZero(polynomial(L,[1,-8,20,-16,chi.mul(4)])));
  check('general_root_cost:'+tag,eq(schurRoot(L),N.scale(I,chi)));
  if(chi.eq(1)) {
    check('selected_two_level_polynomial:'+tag,N.isZero(polynomial(L,[1,-4,2])));
    check('selected_full_rank_and_trace:'+tag,N.rank(L)===8&&trace(L).eq(16));
  }
  cases.push({q:z.q,p:z.p,chi,eta_K:z.eta1,eta_iotaR:z.eta2,two_cut_compatible:both,holonomy:H});
}
const sel=cell(1,1),m=model(sel),{L,I8}=m;
const centredMatrix=N.sub(L,N.scale(I8,2));
check('selected_centred_square',eq(mm(centredMatrix,centredMatrix),N.scale(I8,2)));
check('selected_chiral_pairing',eq(mm(m.Gamma,centredMatrix,m.Gamma),N.scale(centredMatrix,-1)));
check('selected_zero_centred_trace',trace(centredMatrix).zero());
for(const k of ['3/2','2','7/5']) {
  const scale=f(k);
  check('uniform_cost_scale:'+k,N.isZero(polynomial(N.scale(L,scale),[1,scale.mul(-4),scale.pow(2).mul(2)])));
}
check('loop_only_observer_needs_no_extra_memory',N.rowClosure(E,[sel.H,adj(sel.H)]).extra===0);
check('edge_observer_retains_one_extra_coordinate',N.rowClosure(E,[sel.U,sel.V,adj(sel.U),adj(sel.V)]).extra===1);
const onecut=cell(1,'1/2');
control('one_cut_does_not_quantise_holonomy',N.isZero(N.commutator(onecut.H,P))&&!N.isZero(N.commutator(onecut.H,P2))&&onecut.chi.eq('16/25'));
control('loop_closure_does_not_erase_edge_memory',N.rowClosure(E,[sel.H]).rank===1&&N.rowClosure(E,[sel.U,sel.V]).rank===2);
control('literal_path_equality_rejects_nontrivial_phase',eq(mm(E,sel.H),N.scale(E,-1))&&!eq(mm(E,sel.H),E));
const rho=N.matrix([[1,0],[0,0]]),flat=model(cell(0,0));
control('density_blindness_does_not_equal_cell_response',eq(mm(sel.H,rho,adj(sel.H)),rho)&&N.rank(flat.L)===6&&N.rank(L)===8);

const frame=[cell('1/3','1/4').U,cell('1/4','2/3').V,R,sel.V];
const G=N.zeros(8);frame.forEach((v,k)=>{for(let i=0;i<2;i++)for(let j=0;j<2;j++)G[2*k+i][2*k+j]=v[i][j];});
const changed=m.edges.map((T,k)=>mm(frame[(k+1)%4],T,adj(frame[k])));
const Sp=shift(changed),Lp=N.sub(N.scale(I8,2),N.add(Sp,adj(Sp)));
check('full_cell_frame_covariance',eq(Lp,mm(G,L,adj(G))));
check('two_level_frame_invariance',N.isZero(polynomial(Lp,[1,-4,2])));

// Acquired response, not a fitted or imported zeta source.
function response(t){t=f(t);return t.add(2).div(t.pow(2).add(t.mul(4)).add(2));}
function derivative(t){t=f(t);return t.pow(2).add(t.mul(4)).add(6).neg().div(t.pow(2).add(t.mul(4)).add(2).pow(2));}
const tests=['0','1','2','3','10'],responses=[];
for(const value of tests) {
  const t=f(value),inv=N.inverse(N.add(L,N.scale(I8,t)));
  const formula=N.scale(N.sub(N.scale(I8,t.add(4)),L),f(1).div(t.pow(2).add(t.mul(4)).add(2)));
  check('full_resolvent:'+value,eq(inv,formula));
  check('root_response:'+value,eq(inv.slice(0,2).map(r=>r.slice(0,2)),N.scale(I,response(t))));
  responses.push({t,response:response(t)});
}
function acquired(nodes) {
  const n=nodes.length,u=N.matrix(nodes.map(t=>[response(t)]));
  const A=N.zeros(n),B=N.zeros(n);
  for(let i=0;i<n;i++)for(let j=0;j<n;j++){
    const x=f(nodes[i]),y=f(nodes[j]);
    A[i][j]=Cut.of(i===j?derivative(x).neg():response(x).sub(response(y)).div(x.sub(y)).neg());
    B[i][j]=Cut.of(i===j?response(x).add(x.mul(derivative(x))):x.mul(response(x)).sub(y.mul(response(y))).div(x.sub(y)));
  }
  return {pairing:A,source:B,u};
}
const obs=acquired([1,2]), pencil=mm(N.inverse(obs.pairing),obs.source);
check('acquired_pairing_positive',det2(obs.pairing).eq('1/4802')&&obs.pairing[0][0].eq('11/49'));
check('acquired_source_positive',det2(obs.source).eq('1/2401')&&obs.source[0][0].eq('10/49'));
check('exact_acquired_pairing',eq(obs.pairing,N.matrix([['11/49','1/7'],['1/7','9/98']])));
check('exact_acquired_operator',eq(pencil,N.matrix([[-8,-7],[14,12]])));
check('acquired_self_adjointness',eq(mm(adj(pencil),obs.pairing),mm(obs.pairing,pencil))&&eq(mm(obs.pairing,pencil),obs.source));
check('acquired_same_two_levels',N.isZero(polynomial(pencil,[1,-4,2])));
for(const t of tests)check('source_pencil_response:'+t,mm(adj(obs.u),N.inverse(N.add(obs.source,N.scale(obs.pairing,t))),obs.u)[0][0].eq(response(t)));
const third=acquired([1,2,3]);
const ell=N.matrix(third.pairing.slice(0,2).map(r=>[r[2]])),jcol=N.matrix(third.source.slice(0,2).map(r=>[r[2]]));
const alpha=third.pairing[2][2].sub(mm(adj(ell),N.inverse(obs.pairing),ell)[0][0]);
const beta=third.source[2][2].sub(mm(adj(jcol),N.inverse(obs.source),jcol)[0][0]);
check('third_reading_exact_saturation',alpha.zero()&&beta.zero()&&N.rank(third.pairing)===2&&N.rank(third.source)===2);
control('finite_cell_not_all_order_RH_source',alpha.zero()&&beta.zero());
const offaxis=new Cut('1/4','1/4');
control('reflection_symmetries_do_not_pin_all_zeros',offaxis.mul(offaxis).mul(offaxis).mul(offaxis).add('1/64').zero()&&!offaxis.rad.zero());

// Stationary root law survives this weighted subdivision; the full spectrum changes.
const finer=m.edges.flatMap(T=>[I,T]),S8=shift(finer),I16=N.identity(16);
const refined=N.scale(N.sub(N.scale(I16,2),N.add(S8,adj(S8))),2);
check('refinement_preserves_root_cost',eq(schurRoot(refined),I));
control('refinement_does_not_preserve_selected_gap',N.rank(polynomial(refined,[1,-4,2]))===16);

// A first genuine gluing: two central-minus four-cycles share one root.
function graphCost(vertices,edges) {
  const D=N.zeros(2*edges.length,2*vertices);
  edges.forEach(({from,to,T},k)=>{for(let i=0;i<2;i++)for(let j=0;j<2;j++){
    D[2*k+i][2*from+j]=T[i][j].neg();D[2*k+i][2*to+j]=I[i][j];
  }});
  return mm(adj(D),D);
}
const gluedEdges=[];
for(let k=0;k<2;k++){
  const a=1+3*k,b=a+1,c=a+2;
  gluedEdges.push({from:0,to:a,T:I},{from:a,to:b,T:I},{from:b,to:c,T:I},{from:c,to:0,T:N.scale(I,-1)});
}
const glued=graphCost(7,gluedEdges),I14=N.identity(14);
check('glued_positive_full_rank',N.rank(glued)===14);
check('glued_exact_spectral_polynomial',N.isZero(polynomial(glued,[1,-12,50,-88,64,-16])));
check('glued_local_bands_multiplicity',N.rank(polynomial(glued,[1,-4,2]))===6);
check('glued_middle_multiplicity',N.rank(N.sub(glued,N.scale(I14,2)))===12);
check('glued_collective_bands_multiplicity',N.rank(polynomial(glued,[1,-6,4]))===10);
check('glued_root_schur_additivity',eq(schurRoot(glued),N.scale(I,2)));
const rootObserver=N.zeros(2,14);rootObserver[0][0]=Cut.of(1);rootObserver[1][1]=Cut.of(1);
const rootClosure=N.rowClosure(rootObserver,[glued]);
check('glued_root_future_closure_rank',rootClosure.rank===4);
for(const t of tests){
  const z=f(t),r=z.add(2).div(z.pow(2).add(z.mul(6)).add(4));
  const readout=mm(rootObserver,N.inverse(N.add(glued,N.scale(I14,z))),adj(rootObserver));
  check('glued_root_response:'+t,eq(readout,N.scale(I,r)));
}
control('root_response_does_not_see_full_glued_spectrum',rootClosure.rank===4&&glued.length===14&&N.rank(polynomial(glued,[1,-6,4]))===10);

const output={
 schema:'clock-free-two-cut-selection.v1',
 status:'PASS_NATIVE_TWO_CUT_CELL',
 scope:'Clock-free operator-level sector selection and finite exact spectrum; physical quantum gravity and RH are not proved.',
 assumptions:['native cut field and positive pairing','rank-two local carrier','two independent real central Cayley parameters','four-cycle and unit quadratic mismatch weights','exact compatibility of the loop with two noncommuting cuts selects the sector'],
 presentations,certificates,checks,negative_controls:controls,cases,
 selected:{parameters:{q:'1',p:'1'},holonomy:sel.H,chi:sel.chi,shift:m.S,cost_operator:L,centred_operator:centredMatrix,
   minimal_polynomial:['1','-4','2'],levels:['2-sqrt(2)','2+sqrt(2)'],multiplicity_each:4,scale_free_level_ratio:'3+2sqrt(2)',
   intrinsic_spectral_cut:'(L-2I)/sqrt(2); requires native real completion for sqrt(2), not floating arithmetic'},
 one_cut_counterexample:onecut,
 response:{formula:'(t+2)/(t^2+4t+2)',values:responses,pairing:obs.pairing,source:obs.source,operator:pencil,probe:obs.u,
   third_innovations:{alpha,beta},third_ranks:{pairing:N.rank(third.pairing),source:N.rank(third.source)},
   finite_pullback:'det(L+(s-1/2)^2 I)=((s-1/2)^4+4(s-1/2)^2+2)^4; not xi(s)'},
 refinement:{root_cost_preserved:true,old_minimal_polynomial_on_refined_operator_rank:16},
 gluing:{vertices:7,links:8,cost_operator:glued,minimal_polynomial:['1','-12','50','-88','64','-16'],
   levels:[{level:'2-sqrt(2)',multiplicity:4},{level:'2+sqrt(2)',multiplicity:4},{level:'2',multiplicity:2},{level:'3-sqrt(5)',multiplicity:2},{level:'3+sqrt(5)',multiplicity:2}],
   root_schur_operator:'2I',root_response:'(t+2)/(t^2+6t+4)',root_future_closure_rank:rootClosure.rank,full_carrier_rank:14},
 summary:{symbolic_identities:certificates.length,serialized_replays:certificates.length,parameter_pairs:cases.length,exact_checks:checks.length,negative_controls:controls.length}
};
const serialized=JSON.stringify(output,null,2)+'\n';
const file=path.join(root,'QUANTISATION_RESULT.json');
if(process.argv.includes('--check'))assert.equal(fs.readFileSync(file,'utf8'),serialized,'Recorded output differs from exact replay');
else fs.writeFileSync(file,serialized);
console.log(JSON.stringify({status:output.status,mode:process.argv.includes('--check')?'read-only replay':'generate',...output.summary,selected_levels:output.selected.levels,one_cut_chi:onecut.chi,acquired_operator:pencil,third_innovations:{alpha,beta}},null,2));
