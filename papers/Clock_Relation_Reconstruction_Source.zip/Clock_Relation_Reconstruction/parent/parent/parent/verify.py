"""Python 3.12 orchestration; native mathematical arithmetic stays in Node."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys


def require(condition: bool, message: str) -> None:
    if not condition:
        raise SystemExit(message)


require(sys.version_info[:2] == (3, 12), "This packet requires Python 3.12.")
root = Path(__file__).resolve().parent
for base in (root, root / "baseline"):
    manifest = json.loads((base / "MANIFEST.json").read_text(encoding="utf-8"))
    for item in manifest["files"]:
        path = base / item["path"]
        require(path.is_file(), "Missing packaged file: " + str(path.relative_to(root)))
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        require(digest == item["sha256"], "Integrity mismatch: " + str(path.relative_to(root)))

for pin in json.loads((root / "SOURCE_PINS.json").read_text())["records"]:
    if "git_blob_sha1" not in pin:
        continue
    data = (root / pin["path"]).read_bytes()
    blob = b"blob " + str(len(data)).encode("ascii") + b"\0" + data
    digest = hashlib.sha1(blob).hexdigest()
    require(digest == pin["git_blob_sha1"], "Upstream blob mismatch: " + pin["path"])

for pin in json.loads((root / "baseline/LOCAL_SOURCE_PINS.json").read_text())["records"]:
    path = root / "baseline" / pin["local_path"]
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    require(digest == pin["sha256"], "Native dependency changed: " + pin["local_path"])

subprocess.run(
    ["node", str(root / "verify_quantisation.cjs"), "--check"],
    check=True,
    cwd=root,
)
print("Packaged integrity, upstream source pins and exact native replay passed.")
