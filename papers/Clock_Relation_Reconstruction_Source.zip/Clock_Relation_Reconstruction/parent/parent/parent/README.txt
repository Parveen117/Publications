CLOCK-FREE CUT QUANTISATION — VERSION 0.2
14 October 2026

Start with Clock_Free_Cut_Quantisation.pdf (nine pages).

This is an exact finite-model development using the unchanged Recognition
Kernel native arithmetic and Paninian proof compiler. It extends the included
baseline cell with independent transport parameters, a two-cut compatibility
theorem, whole-cell operator levels, and the first two-cell gluing.

Main conditional result
-----------------------
Two predeclared noncommuting rank-one local cuts, preserved by a determinant-one
loop on the rank-two native carrier, force H = +I or -I. On the nontrivial sector,
a four-cycle with unit quadratic link costs has L^2 - 4L + 2I = 0. Its levels are
2 +/- sqrt(2), each with multiplicity four. The level ratio is 3 + 2sqrt(2).
No physical time coordinate or time-evolution interpretation is introduced.

The first gluing has 7 vertices, 8 links, and 14 native complex coordinates.
Its full operator has five distinct levels. The shared-root observer sees only
the collective levels 3 +/- sqrt(5); its operation closure has rank 4.

The SE48/SE49 positive-pencil machinery reconstructs the finite cell response.
This is not an identification with the actual xi source and is not an RH proof.
The levels are cost-operator readings, not identified physical masses/energies.

Reproduce
---------
Requirements: Python 3.12; Node.js (verified with Node 24.19.0).
No pip/npm installation or network access is required for replay.

    python3.12 verify.py

The entry point checks packaged SHA-256 hashes, pinned Git source blobs and
unchanged native dependencies, then performs the read-only native replay:

    node verify_quantisation.cjs --check

Expected summary:
    PASS_NATIVE_TWO_CUT_CELL
    10 symbolic identities and 10 serialized replays
    25 rational parameter pairs
    354 exact checks
    8 negative controls

Python only orchestrates processes and checks file integrity. Mathematical
arithmetic remains in baseline/native/core/native_operator.cjs. Polynomial
certificates use baseline/native/core/paninian_operator.cjs. The read-only
command compares the entire reproduced JSON with QUANTISATION_RESULT.json.
The archive manifest is an integrity aid, not an external digital signature.

Contents
--------
Clock_Free_Cut_Quantisation.pdf   Result, assumptions, proofs and boundaries
Clock_Free_Cut_Quantisation.tex   Editable LaTeX source
verify.py                       Python 3.12 integrity/replay entry point
verify_quantisation.cjs          Native construction and exact certificates
QUANTISATION_RESULT.json         Recorded exact output
SOURCE_PINS.json                 Immutable source URLs and Git blob IDs
SOURCE_AUDIT.txt                 Reuse and audit scope
MANIFEST.json                    SHA-256 manifest (excluding itself)
sources/                        Pinned relevant sources and uncertified draft
baseline/                       Complete unchanged previous cell source packet

Build the note with a standard TeX Live installation including lmodern and tikz:
    pdflatex Clock_Free_Cut_Quantisation.tex
    pdflatex Clock_Free_Cut_Quantisation.tex
Build products will not be in the original integrity manifest.

Scope
-----
The two-cut condition is an extra observer contract. It is not implied by
unitarity and does not force selection of the nontrivial sector. Enforcing it
on every face would remove noncentral projective holonomy. A richer geometry
must retain cut defects and their predictive memory.

Uniform rescaling of link costs preserves the displayed ratio. A tested
weighted subdivision preserves the static root cost but changes the full
spectrum. No universal continuum gap is claimed.

The new cell response is finite and saturates at two independent probe readings.
The existing RH branch already has its own actual-source adapter; its global
positivity requirements are not discharged by this finite calculation.

No external repository was modified or published by this packet.
