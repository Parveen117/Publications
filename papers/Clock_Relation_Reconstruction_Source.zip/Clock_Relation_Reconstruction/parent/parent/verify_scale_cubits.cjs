'use strict';
// All scalar and matrix arithmetic is performed by the unchanged native engine.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const assert=require('node:assert/strict'),root=__dirname;
for(const pin of JSON.parse(fs.readFileSync(path.join(root,'parent/baseline/LOCAL_SOURCE_PINS.json'))).records)
  assert.equal(crypto.createHash('sha256').update(fs.readFileSync(path.join(root,'parent/baseline',pin.local_path))).digest('hex'),pin.sha256,pin.local_path);
const N=require('./parent/baseline/native/core/native_operator.cjs');
const M=require('./parent/baseline/native/core/paninian_operator.cjs');
const {F,Cut,IOTA}=N,f=x=>F.of(x),I=N.identity(2);
const R=N.matrix([[0,-1],[1,0]]),K=N.matrix([[0,1],[1,0]]),Z=N.scale(N.mul(R,K),-1);
const mm=(...xs)=>xs.reduce((a,b)=>N.mul(a,b)),adj=N.dagger,eq=N.equal;
const checks=[],controls=[],certificates=[],presentations=[];
const check=(name,ok,detail={})=>{assert.ok(ok,name);checks.push({name,passed:true,...detail});};
const control=(name,ok,detail={})=>{assert.ok(ok,name);controls.push({name,false_inference_rejected:true,...detail});};
const trace=A=>A.reduce((z,row,i)=>z.add(row[i]),Cut.of(0));
function record(n,d=1){
  n=f(n);d=f(d);if(d.zero())throw new RangeError('Finite comparison chart requires nonzero denominator');
  const norm=n.pow(2).add(d.pow(2)),v=N.matrix([[d],[n]]);
  const P=N.scale(mm(v,adj(v)),f(1).div(norm)),C=N.sub(N.scale(P,2),I);
  return {n,d,ratio:n.div(d),norm,v,P,C};
}
function proof(S,name,lhs,rhs){
  const p=M.proveEquality(lhs,rhs);
  check(name,p.status==='EQUAL_IN_DECLARED_QUOTIENT');
  const cert=JSON.parse(JSON.stringify(p.certificate));
  check(name+':serialized_replay',S.replay(cert)===true);
  certificates.push({name,certificate:cert});
}
function admit(S,name,starMap){
  const audit=S.audit(),gate=M.daggerGate(S,starMap);
  check(name+':confluence',audit.status==='CONFLUENT_BY_CHECKED_DIAMONDS');
  check(name+':dagger',gate.status==='DAGGER_DESCENDS');
  presentations.push({name,spec:S.spec(),audit,dagger_status:gate.status});
}
function centralPresentation(tokens,name){
  const rules=[];
  for(let j=1;j<tokens.length;j++)for(let i=0;i<j;i++)
    rules.push({id:tokens[j]+'_'+tokens[i],lhs:[tokens[j],tokens[i]],rhs:[[[tokens[i],tokens[j]],1]],source:'Declared real central comparison parameters; native lawful composition'});
  const S=new M.Presentation({tokens,rules}),w=Object.fromEntries(tokens.map(t=>[t,S.word([t])]));
  admit(S,name,w);return {S,w};
}
const times=(...ps)=>ps.reduce((a,b)=>a.times(b));
const sq=p=>p.times(p);

// A native comparison cut, represented after the EMK algebra.
const central=['n','d','s'];
const rules=[{id:'RR',lhs:['R','R'],rhs:[[[],-1]]},{id:'KK',lhs:['K','K'],rhs:[[[],1]]},{id:'KR',lhs:['K','R'],rhs:[[['R','K'],-1]]}]
  .map(r=>({...r,source:'Canonical native EMK relations'}));
for(const c of central)for(const t of ['R','K'])rules.push({id:c+t,lhs:[c,t],rhs:[[[t,c],1]],source:'Declared real central comparison coordinate'});
for(let j=1;j<central.length;j++)for(let i=0;i<j;i++)rules.push({id:central[j]+central[i],lhs:[central[j],central[i]],rhs:[[[central[i],central[j]],1]],source:'Declared commuting record coordinates'});
const S=new M.Presentation({tokens:['R','K',...central],rules});
const rr=S.word(['R']),kk=S.word(['K']),nn=S.word(['n']),dd=S.word(['d']),ss=S.word(['s']);
const star={R:rr.scale(-1),K:kk,n:nn,d:dd,s:ss};admit(S,'native_comparison_cut',star);
const zz=rr.times(kk).scale(-1),norm=sq(nn).plus(sq(dd));
const cnum=sq(dd).minus(sq(nn)).times(zz).plus(dd.times(nn).times(kk).scale(2));
const pnum=norm.plus(cnum).scale('1/2');
proof(S,'comparison_circle_identity',sq(sq(dd).minus(sq(nn))).plus(sq(dd.times(nn).scale(2))),sq(norm));
proof(S,'comparison_cut_self_dagger',M.star(cnum,star),cnum);
proof(S,'comparison_cut_involution',sq(cnum),sq(norm));
proof(S,'comparison_projector_idempotence',sq(pnum),norm.times(pnum));
const cs=sq(ss.times(dd)).minus(sq(ss.times(nn))).times(zz).plus(times(ss,dd,ss,nn,kk).scale(2));
proof(S,'common_scale_homogeneity',cs,sq(ss).times(cnum));
proof(S,'reciprocal_record_cut',times(kk,cnum,kk),sq(nn).minus(sq(dd)).times(zz).plus(dd.times(nn).times(kk).scale(2)));

const rec=centralPresentation(['n','d','a','b'],'record_composition'),w=rec.w;
proof(rec.S,'tensor_record_minor',times(w.n,w.a,w.d,w.b),times(w.n,w.b,w.d,w.a));
proof(rec.S,'independent_scale_correction',times(w.b,w.a,w.n,w.d),times(w.a,w.b,w.d,w.n));
proof(rec.S,'retained_tensor_norm',sq(w.n).plus(sq(w.d)).times(sq(w.a).plus(sq(w.b))),
  sq(w.d.times(w.b)).plus(sq(w.d.times(w.a))).plus(sq(w.n.times(w.b))).plus(sq(w.n.times(w.a))));

const phys=centralPresentation(['l','e','A','B','a','b'],'physical_comparison_contract'),x=phys.w;
const Fq=times(x.a,x.e,x.l).minus(x.A),Fp=times(x.b,x.B,x.e).minus(x.l);
proof(phys.S,'selected_length_residual',x.a.times(sq(x.l)).minus(times(x.b,x.A,x.B)),
  times(x.b,x.B,Fq).minus(times(x.a,x.l,Fp)));
proof(phys.S,'selected_energy_residual',times(x.a,x.b,x.B,sq(x.e)).minus(x.A),
  Fq.plus(times(x.a,x.e,Fp)));
const qn=times(x.a,x.e,x.l),qd=x.A,pn=times(x.b,x.B,x.e),pd=x.l;
proof(phys.S,'general_ratio_relation',times(x.a,pn,qd,sq(x.l)),times(x.b,qn,pd,x.A,x.B));
proof(phys.S,'general_product_relation',times(qn,pn,x.A),times(x.a,x.b,x.B,sq(x.e),qd,pd));

// Finite exact checks include zero and signed numerator charts.
const records=[];
for(const n of [-3,-1,0,1,2,5])for(const d of [1,2,3]){
  const c=record(n,d),tag=n+'/'+d;
  check('projector:'+tag,eq(mm(c.P,c.P),c.P)&&eq(adj(c.P),c.P)&&trace(c.P).eq(1));
  check('involution:'+tag,eq(mm(c.C,c.C),I)&&eq(adj(c.C),c.C));
  check('native_EMK_chart:'+tag,eq(c.C,N.add(N.scale(Z,c.d.pow(2).sub(c.n.pow(2)).div(c.norm)),N.scale(K,c.n.mul(c.d).mul(2).div(c.norm)))));
  check('record_readback:'+tag,c.P[1][0].div(c.P[0][0]).eq(c.ratio));
  check('common_scale_invariant:'+tag,eq(record(c.n.mul(7),c.d.mul(7)).P,c.P));
  const observed=record(c.n.mul(7),c.d.mul(11));
  check('independent_scale_compensation:'+tag,eq(record(observed.n.mul(11),observed.d.mul(7)).P,c.P));
  if(!c.n.zero())check('reciprocal_record:'+tag,eq(mm(K,c.P,K),record(c.d,c.n).P));
  records.push(c);
}

// The product comparison is a cut of a four-coordinate retained tensor record.
const productRead=N.matrix([[1,0,0,0],[0,0,0,1]]),memoryRead=N.matrix([[0,1,0,0],[0,0,1,0]]);
const retained=N.matrix([...productRead,...memoryRead]);
function productProjector(A,B){const out=mm(productRead,N.kron(A,B),adj(productRead));return N.scale(out,trace(out).inv());}
const productRecords=(...ps)=>ps.reduce((a,b)=>productProjector(a,b));
check('retained_product_and_memory_isometry',eq(mm(adj(retained),retained),N.identity(4)));
for(const u of ['1/3','1','2','3'])for(const v of ['1/3','1','2','3']){
  const a=record(u),b=record(v),tensor=N.kron(a.P,b.P),out=mm(productRead,tensor,adj(productRead));
  const target=record(a.n.mul(b.n),a.d.mul(b.d));
  check('product_comparison:'+u+','+v,eq(N.scale(out,trace(out).inv()),target.P));
  check('retained_tensor_reconstruction:'+u+','+v,eq(mm(adj(retained),retained,tensor,adj(retained),retained),tensor));
}
const closure=N.rowClosure(productRead,[N.kron(K,I),N.kron(I,K)]);
check('product_future_closure_requires_memory',closure.rank===4&&closure.extra===2);
const tensorA=N.kron(record(2).P,record(3).P),tensorB=N.kron(record(1).P,record(6).P);
control('product_ratio_does_not_identify_factors',eq(productProjector(record(2).P,record(3).P),productProjector(record(1).P,record(6).P))&&!eq(tensorA,tensorB));
control('independent_scalings_do_not_cancel_automatically',!eq(record(14,33).P,record(2,3).P));
control('uncoupled_tensor_blocks_do_not_create_curvature',N.isZero(N.commutator(N.kron(R,I),N.kron(I,N.scale(K,IOTA)))));
control('central_signs_can_cancel_on_tensor_product',eq(N.kron(N.scale(I,-1),N.scale(I,-1)),N.identity(4)));

// Unit charges on (ell,E,A,B,R_scalar,Lambda), using length and energy units.
const dimensions=N.matrix([[1,0,1,1,-2,-2],[0,1,1,-1,0,0]]);
const invariants=N.matrix([[1,1,-1,0,0,0],[-1,1,0,1,0,0],[2,0,0,0,1,0],[2,0,0,0,0,1]]);
check('unit_charge_rank_two',N.rank(dimensions)===2);
check('four_independent_unit_invariants',N.rank(invariants)===4&&N.isZero(mm(dimensions,adj(invariants))));
function data(l,e,A,B,a=1,b=1,curv=1,lambda=1){
  [l,e,A,B,a,b,curv,lambda]=[l,e,A,B,a,b,curv,lambda].map(f);
  const epsilon=e.mul(l).div(A),gamma=B.mul(e).div(l),q=a.mul(epsilon),p=b.mul(gamma);
  const U=N.cayley(R,q),V=N.cayley(N.scale(K,IOTA),p),H=mm(adj(V),adj(U),V,U);
  const chi=q.pow(2).mul(p.pow(2)).mul(16).div(f(1).add(q.pow(2)).pow(2).mul(f(1).add(p.pow(2)).pow(2)));
  return {l,e,A,B,a,b,curv,lambda,epsilon,gamma,q,p,H,chi,kappa:curv.mul(l.pow(2)),lambda_l2:lambda.mul(l.pow(2))};
}
const inputs=[[2,3,5,7,'2/3','5/4'],[1,1,1,1,1,1],[3,2,7,5,2,3]],physicalCases=[];
const reference={l0:f(3),e0:f(5),A0:f(7),B0:f(11)};
reference.etaQ=reference.e0.mul(reference.l0).div(reference.A0);
reference.etaG=reference.B0.mul(reference.e0).div(reference.l0);
for(const vals of inputs){
  const z=data(...vals),tag=vals.join(',');
  const re=record(z.e,reference.e0),rl=record(z.l,reference.l0),rA=record(z.A,reference.A0),rB=record(z.B,reference.B0);
  const epsRecord=productRecords(record(reference.etaQ).P,re.P,rl.P,mm(K,rA.P,K));
  const gravRecord=productRecords(record(reference.etaG).P,rB.P,re.P,mm(K,rl.P,K));
  check('quantum_ratio_from_separate_reference_cubits:'+tag,eq(epsRecord,record(z.epsilon).P));
  check('gravity_ratio_from_separate_reference_cubits:'+tag,eq(gravRecord,record(z.gamma).P));
  check('calibrated_q_from_cubit_composition:'+tag,eq(productProjector(record(z.a).P,epsRecord),record(z.q).P));
  check('calibrated_p_from_cubit_composition:'+tag,eq(productProjector(record(z.b).P,gravRecord),record(z.p).P));
  check('physical_ratio_identity:'+tag,z.gamma.div(z.epsilon).eq(z.A.mul(z.B).div(z.l.pow(2))));
  check('physical_product_identity:'+tag,z.epsilon.mul(z.gamma).eq(z.B.mul(z.e.pow(2)).div(z.A)));
  check('calibrated_length_relation:'+tag,z.a.mul(z.p).mul(z.l.pow(2)).eq(z.b.mul(z.q).mul(z.A).mul(z.B)));
  check('calibrated_energy_relation:'+tag,z.q.mul(z.p).mul(z.A).eq(z.a.mul(z.b).mul(z.B).mul(z.e.pow(2))));
  for(const s of ['1/2','2'])for(const t of ['1/3','3']){
    const ls=f(s),es=f(t);
    const y=data(z.l.mul(ls),z.e.mul(es),z.A.mul(ls).mul(es),z.B.mul(ls).div(es),z.a,z.b,z.curv.div(ls.pow(2)),z.lambda.div(ls.pow(2)));
    check('unit_invariance:'+tag+':'+s+','+t,y.q.eq(z.q)&&y.p.eq(z.p)&&y.kappa.eq(z.kappa)&&y.lambda_l2.eq(z.lambda_l2)&&eq(y.H,z.H));
    const g=data(z.l.mul(ls),z.e.mul(es),z.A,z.B,z.a.div(ls.mul(es)),z.b.mul(ls).div(es),z.curv,z.lambda);
    check('physical_calibration_fibre:'+tag+':'+s+','+t,g.q.eq(z.q)&&g.p.eq(z.p)&&eq(g.H,z.H));
  }
  physicalCases.push({...z,reference_cubits:{re,rl,rA,rB},epsilon_projector:epsRecord,gravity_projector:gravRecord});
}
const selected=[];
for(const l of [1,2,3])for(const e of [1,2,3]){
  const a=f(1).div(f(l).mul(e)),b=f(l).div(e),z=data(l,e,1,1,a,b);
  check('same_selected_native_loop:'+l+','+e,z.q.eq(1)&&z.p.eq(1)&&eq(z.H,N.scale(I,-1))&&z.chi.eq(1));
  check('selected_length_balance:'+l+','+e,z.a.mul(z.l.pow(2)).eq(z.b.mul(z.A).mul(z.B)));
  check('selected_energy_balance:'+l+','+e,z.a.mul(z.b).mul(z.B).mul(z.e.pow(2)).eq(z.A));
  const omega=f(3),area=omega.mul(z.l.pow(2)),curvatureSquared=z.chi.div(area.pow(2));
  check('finite_defect_curvature_relation:'+l+','+e,curvatureSquared.mul(z.A.mul(z.B).pow(2)).eq(z.a.pow(2).div(z.b.pow(2).mul(omega.pow(2)))));
  selected.push({...z,omega,area,finite_defect_curvature_squared:curvatureSquared});
}
const z0=selected[0],z1=selected.find(z=>z.l.eq(2)&&z.e.eq(3));
control('native_cell_does_not_fix_unknown_physical_calibrations',eq(z0.H,z1.H)&&!z0.l.eq(z1.l)&&!z0.e.eq(z1.e));
control('retained_calibration_cubits_distinguish_that_ambiguity',!eq(record(z0.a).P,record(z1.a).P)&&!eq(record(z0.b).P,record(z1.b).P));
const calibrationCharges=N.matrix([[1,1,1,0],[-1,1,0,1]]);
const calibrationKernel=N.matrix([[1,0,-1,1],[0,1,-1,-1]]);
check('exact_two_calibration_directions',N.rank(calibrationCharges)===2&&N.rank(calibrationKernel)===2&&N.isZero(mm(calibrationCharges,adj(calibrationKernel))));

// A clock-free physical adapter cannot distinguish c,hbar,G separately.
const c=f(3),hbar=f(5),G=f(7),tau=f(2);
const c2=c.mul(tau),hbar2=hbar.div(tau),G2=G.mul(tau.pow(4));
check('clock_relabel_preserves_A',hbar.mul(c).eq(hbar2.mul(c2)));
check('clock_relabel_preserves_B',G.div(c.pow(4)).eq(G2.div(c2.pow(4))));
control('separate_c_hbar_G_not_determined_by_clock_free_pair',!c.eq(c2)&&!hbar.eq(hbar2)&&!G.eq(G2));
control('uncoupled_cosmological_record_has_no_prediction',eq(data(1,1,1,1,1,1,1,1).H,data(1,1,1,1,1,1,1,2).H));

const parent=JSON.parse(fs.readFileSync(path.join(root,'parent/QUANTISATION_RESULT.json')));
const L=N.matrix(parent.selected.cost_operator),I8=N.identity(8);
check('inherited_selected_cell_polynomial',N.isZero(N.add(N.sub(mm(L,L),N.scale(L,4)),N.scale(I8,2))));
const physicalCost=N.scale(L,3);
check('independent_cost_energy_gain',N.isZero(N.add(N.sub(mm(physicalCost,physicalCost),N.scale(physicalCost,12)),N.scale(I8,18))));
control('transport_source_energy_is_not_an_operator_eigenvalue',N.rank(N.sub(L,I8))===8);

const output={schema:'clock-free-physical-scale-cubits.v1',status:'PASS_NATIVE_SCALE_CUBITS',
 scope:'Native comparison and memory calculus; conditional physical-scale bridge. No empirical quantum gravity or fundamental-constant prediction.',
 assumptions:['Native EMK arithmetic and positive pairing','Real central ratio coordinates with nonzero denominator','Physical dictionary A=hbar*c, B=G/c^4','Explicit adapters q=alpha*E*ell/A and p=beta*B*E/ell','Previous two-cut-compatible nontrivial four-cycle sector is reused, not redefined'],
 presentations,certificates,checks,negative_controls:controls,
 comparison:{record:'v=(d,n); P=v*v_dagger/(d^2+n^2); C=2P-I',records,product_read:productRead,memory_read:memoryRead,retained_permutation:retained,product_future_closure:closure},
 scale_invariants:{quantities:['ell','E','A','B','R_scalar','Lambda'],unit_charge_matrix:dimensions,invariant_exponents:invariants,independent_invariants:['E*ell/A','B*E/ell','R_scalar*ell^2','Lambda*ell^2']},
 physical_cases:physicalCases,reference_factorization:{...reference,epsilon:'etaQ*(E/E0)*(ell/ell0)/(A/A0)',gamma:'etaG*(B/B0)*(E/E0)/(ell/ell0)'},selected_scale_family:selected,
 selected_relations:{length:'alpha*ell^2 = beta*A*B',energy:'alpha*beta*B*E^2 = A',planck_adapter:'ell^2=(beta/alpha)*ell_P^2; E^2=E_P^2/(alpha*beta)',unit_normalization:'alpha=beta=1 gives ell=ell_P and E=E_P; this normalization is an extra adapter condition'},
 unidentified_calibrations:{charge_matrix:calibrationCharges,kernel:calibrationKernel,transformation:'ell->s*ell, E->t*E, alpha->alpha/(s*t), beta->s*beta/t; A,B fixed',dimension:2},
 clock_fibre:{c,hbar,G,tau,c2,hbar2,G2,A:hbar.mul(c),B:G.div(c.pow(4))},
 summary:{symbolic_certificates:certificates.length,serialized_replays:certificates.length,exact_checks:checks.length,negative_controls:controls.length,comparison_records:records.length,selected_calibration_cases:selected.length}
};
const serialized=JSON.stringify(output,null,2)+'\n',file=path.join(root,'SCALE_CUBIT_RESULT.json');
if(process.argv.includes('--check'))assert.equal(fs.readFileSync(file,'utf8'),serialized,'Recorded scale-cubit output differs from exact replay');
else fs.writeFileSync(file,serialized);
console.log(JSON.stringify({status:output.status,mode:process.argv.includes('--check')?'read-only replay':'generate',...output.summary,selected_relations:output.selected_relations,product_future_closure_rank:closure.rank},null,2));
