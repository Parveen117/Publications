CLOCK-FREE PHYSICS CUBITS — VERSION 0.3
14 October 2026

Read Clock_Free_Physics_Cubits.pdf first (eight pages).

Purpose
-------
Represent each unknown quantity and each numerator/denominator scaling as a
native two-coordinate comparison record; compose the records with retained
memory; identify the resulting clock-free physical-scale relations.

The word "cubit" in this packet refers to that mathematical comparison record.
It is not a claim that a quantum device has prepared or measured physical qubits.

Main results
------------
P(n,d) = (d,n)^T(d,n)/(d^2+n^2) is a native rank-one projector and 2P-I an
involution. Common scaling cancels. Independent scaling requires its own
correction record. Multiplication of ratios is an explicit cut of their tensor
record. Two additional coordinates complete its predictive memory for the
specified local-flip catalogue; the full transformed record retains cross terms.

The physical dictionary A=hbar*c, B=G/c^4 supplies the dimensionless ratios
epsilon=E*ell/A and gamma=B*E/ell. Explicit reference-factor records reconstruct
both ratios before transport calibration. Declaring q=alpha*epsilon and
p=beta*gamma, the previously certified positive nontrivial sector q=p=1 gives

    alpha*ell^2 = beta*A*B
    alpha*beta*B*E^2 = A.

Thus ell^2=(beta/alpha)*ell_P^2 and E^2=E_P^2/(alpha*beta).
The conventional Planck branch alpha=beta=1 is an extra normalization condition.
It is not derived as the unique physical calibration. At fixed A,B,q,p the
positive solution family has exactly two calibration degrees of freedom.

No numerical value of a physical constant, no cosmological field equation and
no physical quantum-gravity theory are inferred from these finite identities.
The proposed physical adapter and the native theorem are kept separate.

Reproduce
---------
Requirements: Python 3.12 and Node.js (verified using Node 24.19.0).
No network access or additional packages are needed for exact replay.

    python3.12 verify.py

Expected summary:
    PASS_NATIVE_SCALE_CUBITS
    13 symbolic certificates, each serialized and replayed
    280 exact checks
    9 negative controls
    18 comparison records
    9 examples of the selected calibration family

The Python wrapper checks packaged and inherited file integrity, upstream
source pins and unchanged native dependencies, then launches

    node verify_scale_cubits.cjs --check

All mathematical scalar/matrix arithmetic uses the existing native engine.
Python is only an orchestration and integrity layer. The read-only replay
compares the entire newly generated result with SCALE_CUBIT_RESULT.json.

The complete prior packet is preserved under parent/. Its source provenance,
assumptions and claim boundaries remain applicable. The main verifier checks
the inherited manifests; this task does not claim a new replay of every
unrelated upstream repository test suite.

Files
-----
Clock_Free_Physics_Cubits.pdf   Eight-page development and proofs
Clock_Free_Physics_Cubits.tex   Editable LaTeX source
verify_scale_cubits.cjs        Exact native construction and certificates
SCALE_CUBIT_RESULT.json        Recorded result and all exact records
PHYSICS_ADAPTERS.json          Physical dictionary, attribution and open ports
verify.py                     Python 3.12 entry point
MANIFEST.json                 SHA-256 integrity manifest, excluding itself
parent/                       Unchanged prior cut-quantisation packet

PDF build: pdflatex Clock_Free_Physics_Cubits.tex, twice.
The TeX source uses standard TeX Live packages including lmodern and mathrsfs.
The manifest records the delivered packet, not files subsequently generated
by a local document rebuild. It is not an external digital signature.

No external repository was changed or published in this development.
