'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const assert=require('node:assert/strict'),root=__dirname;
const base='parent/parent/baseline';
for(const pin of JSON.parse(fs.readFileSync(path.join(root,base,'LOCAL_SOURCE_PINS.json'))).records)
  assert.equal(crypto.createHash('sha256').update(fs.readFileSync(path.join(root,base,pin.local_path))).digest('hex'),pin.sha256,pin.local_path);
const N=require('./parent/parent/baseline/native/core/native_operator.cjs');
const M=require('./parent/parent/baseline/native/core/paninian_operator.cjs');
const {F,Cut,IOTA}=N,f=x=>F.of(x),I=N.identity(2);
const R=N.matrix([[0,-1],[1,0]]),K=N.matrix([[0,1],[1,0]]);
const mm=(...xs)=>xs.reduce((a,b)=>N.mul(a,b)),adj=N.dagger,eq=N.equal;
const checks=[],controls=[],certificates=[],presentations=[];
const check=(name,ok,detail={})=>{assert.ok(ok,name);checks.push({name,passed:true,...detail});};
const control=(name,ok,detail={})=>{assert.ok(ok,name);controls.push({name,false_inference_rejected:true,...detail});};
const trace=A=>A.reduce((z,row,i)=>z.add(row[i]),Cut.of(0));
const sign=x=>{x=f(x);return x.zero()?0:x.le(0)?-1:1;};
function requirePositive(x,name){x=f(x);assert.ok(!x.zero()&&!x.le(0),name+' must be positive');return x;}

// Exact rational-root adapter: every arithmetic operation uses the native F.
// It accepts only perfect rational squares; no approximation or float fallback.
function integerRoot(n){
  n=f(n);assert.ok(n.d===1n&&!n.le(-1));if(n.zero())return f(0);
  let bit=f(1),answer=f(0);
  while(bit.pow(2).le(n))bit=bit.mul(2);
  while(!bit.eq(1)){
    bit=bit.div(2);const trial=answer.add(bit);
    if(trial.pow(2).le(n))answer=trial;
  }
  assert.ok(answer.pow(2).eq(n),'Non-rational square root: retain a native real-completion root instead');
  return answer;
}
function sqrtExact(z){
  z=f(z);assert.ok(!z.le(-1)&&sign(z)>=0,'Negative square-root input');
  const out=integerRoot(f(z.n)).div(integerRoot(f(z.d)));
  assert.ok(out.pow(2).eq(z));return out;
}
function cell(q,p){
  q=requirePositive(q,'q');p=requirePositive(p,'p');
  const U=N.cayley(R,q),V=N.cayley(N.scale(K,IOTA),p),H=mm(adj(V),adj(U),V,U);
  const amp=q.mul(p).mul(4).div(f(1).add(q.pow(2)).mul(f(1).add(p.pow(2))));
  const chi=amp.pow(2),r=q.div(p),k=q.mul(p);
  const moment=trace(mm(N.sub(R,N.scale(K,IOTA)),H)).neg().div(chi.mul(4));
  assert.ok(moment.turn.zero());
  return {q,p,U,V,H,amp,chi,r,k,oriented_moment:moment.rad};
}
function probe(q,p,s=1,t=1){s=requirePositive(s,'length ratio');t=requirePositive(t,'source-energy ratio');return cell(f(q).mul(s).mul(t),f(p).mul(t).div(s));}
function amplitudeRead(chi){chi=requirePositive(chi,'chi');assert.ok(chi.le(1),'chi exceeds the admitted loop range');return f(4).div(sqrtExact(chi));}
function positiveRootDifference(delta){delta=f(delta);const z=delta.add(sqrtExact(delta.pow(2).add(1))).div(2);assert.ok(sign(z)>0);return z;}

// Decoder receives only three normalized scalar readings, with known s=t=2.
// Squared balance ratios retain possible irrational real-completion roots.
function reconstructRational(readings){
  const Y0=amplitudeRead(readings.base),YL=amplitudeRead(readings.length2),YE=amplitudeRead(readings.energy2);
  const dl=YL.sub(Y0).div(3),de=YE.sub(Y0).div(3),r=positiveRootDifference(dl),k=positiveRootDifference(de);
  assert.ok(r.add(f(1).div(r)).add(k).add(f(1).div(k)).eq(Y0),'Three readings violate the constant-calibration model');
  const q=sqrtExact(r.mul(k)),p=sqrtExact(k.div(r)),Y22=YL.add(YE).sub(Y0);
  return {q,p,r,k,Y0,YL,YE,dl,de,predicted22:f(16).div(Y22.pow(2)),balance_length_ratio_squared:f(1).div(r),balance_energy_ratio_squared:f(1).div(k)};
}
function lengthOnly(readings){
  const Y0=amplitudeRead(readings.base),YL=amplitudeRead(readings.length2);
  const r=positiveRootDifference(YL.sub(Y0).div(3));
  const a=Y0.sub(r).sub(f(1).div(r));assert.ok(f(2).le(a));
  const disc=sqrtExact(a.pow(2).sub(4));
  const k1=a.add(disc).div(2),k2=a.sub(disc).div(2);
  return {r,a,candidates:[k1,k2].map(k=>({k,q:sqrtExact(k.mul(r)),p:sqrtExact(k.div(r))}))};
}
function proof(S,name,lhs,rhs){
  const p=M.proveEquality(lhs,rhs);check(name,p.status==='EQUAL_IN_DECLARED_QUOTIENT');
  const certificate=JSON.parse(JSON.stringify(p.certificate));check(name+':serialized_replay',S.replay(certificate)===true);
  certificates.push({name,certificate});
}
function admit(S,name,star){const audit=S.audit(),dagger=M.daggerGate(S,star);check(name+':confluence',audit.status==='CONFLUENT_BY_CHECKED_DIAMONDS');check(name+':dagger',dagger.status==='DAGGER_DESCENDS');presentations.push({name,spec:S.spec(),audit,dagger_status:dagger.status});}
function commutative(tokens,name){const rules=[];for(let j=1;j<tokens.length;j++)for(let i=0;i<j;i++)rules.push({id:tokens[j]+'_'+tokens[i],lhs:[tokens[j],tokens[i]],rhs:[[[tokens[i],tokens[j]],1]],source:'Declared real central native scale/source parameters'});const S=new M.Presentation({tokens,rules}),w=Object.fromEntries(tokens.map(x=>[x,S.word([x])]));admit(S,name,w);return {S,w};}
const times=(...xs)=>xs.reduce((a,b)=>a.times(b)),sq=x=>x.times(x);
const C=commutative(['q','p','s','t'],'scale_source_polynomials'),w=C.w,o=C.S.one();
function den(s,t){return o.plus(sq(times(w.q,s,t))).times(sq(s).plus(sq(w.p.times(t))));}
const dst=den(w.s,w.t),ds=den(w.s,o),dt=den(o,w.t),d0=den(o,o);
proof(C.S,'inverse_amplitude_separates',dst,sq(w.s).plus(sq(w.p.times(w.t))).plus(times(sq(w.q),sq(sq(w.s)),sq(w.t))).plus(times(sq(w.q),sq(w.p),sq(w.s),sq(sq(w.t)))));
proof(C.S,'scale_rectangle_identity',dst.minus(sq(w.t).times(ds)).minus(sq(w.s).times(dt)).plus(times(sq(w.s),sq(w.t),d0)),C.S.zero());
proof(C.S,'length_difference_factorization',ds.minus(sq(w.s).times(d0)),sq(w.s).minus(o).times(times(sq(w.q),sq(w.s)).minus(sq(w.p))));
proof(C.S,'energy_difference_factorization',dt.minus(sq(w.t).times(d0)),sq(w.t).minus(o).times(times(sq(w.q),sq(w.p),sq(w.t)).minus(o)));
proof(C.S,'whole_length_curve_duality',ds,sq(w.p).plus(sq(w.s)).times(sq(w.q.times(w.s)).plus(o)));
const centredDen=o.plus(sq(w.s.times(w.t))).times(sq(w.s).plus(sq(w.t)));
proof(C.S,'exact_scale_compass_circle',centredDen.minus(times(sq(w.s),sq(w.t)).scale(4)),sq(sq(w.s).minus(o)).times(sq(w.t)).plus(sq(sq(w.t).minus(o)).times(sq(w.s))));

const J=new M.Presentation({tokens:['j'],rules:[{id:'j2',lhs:['j','j'],rhs:[],source:'Declared first-order native jet quotient j^2=0, used only for local sensitivity'}]});
const j=J.word(['j']),jo=J.one();admit(J,'native_first_order_jet',{j});
const chi0=f('256/625'),slope=f('1536/3125');
function jetChi(name,q,p,s,t,derivative){
  const qq=q.scale(s),pp=p.scale(t),num=sq(qq).times(sq(pp)).scale(16);
  const denominator=sq(jo.plus(sq(qq))).times(sq(jo.plus(sq(pp))));
  proof(J,name,num,jo.scale(chi0).plus(j.scale(derivative)).times(denominator));
}
jetChi('length_probe_q_sensitivity',jo.plus(j),jo,2,'1/2',slope.neg());
jetChi('length_probe_p_sensitivity',jo,jo.plus(j),2,'1/2',slope);
jetChi('energy_probe_q_sensitivity',jo.plus(j),jo,2,2,slope.neg());
jetChi('energy_probe_p_sensitivity',jo,jo.plus(j),2,2,slope.neg());

function shift(edges){const S=N.zeros(8);edges.forEach((T,k)=>{for(let i=0;i<2;i++)for(let j=0;j<2;j++)S[2*((k+1)%4)+i][2*k+j]=T[i][j];});return S;}
function cost(z){const S=shift([z.U,z.V,adj(z.U),adj(z.V)]);return N.sub(N.scale(N.identity(8),2),N.add(S,adj(S)));}
function graphCost(edges,weights){
  const n=edges.length,dim=2*n;let A=N.zeros(dim);
  for(let k=0;k<n;k++){
    const D=N.zeros(2,dim),target=(k+1)%n;
    for(let i=0;i<2;i++)for(let j=0;j<2;j++){D[i][2*k+j]=edges[k][i][j].neg();D[i][2*target+j]=I[i][j];}
    A=N.add(A,N.scale(mm(adj(D),D),weights[k]));
  }
  return A;
}
function schurRoot(A){const B=A.slice(0,2).map(r=>r.slice(0,2)),X=A.slice(0,2).map(r=>r.slice(2)),C=A.slice(2).map(r=>r.slice(2));return N.sub(B,mm(X,N.inverse(C),adj(X)));}
function scalarReal(z){assert.ok(z.turn.zero());return z.rad;}
function normalizeReading(reading){return f(reading.normalizer).mul(f(reading.effective_trace)).div(f(reading.bare_trace));}
function rawCycleReading(z,gain,relativeWeights,refine=false){
  gain=requirePositive(gain,'readout gain');let edges=[z.U,z.V,adj(z.U),adj(z.V)];
  if(refine)edges=edges.flatMap(T=>[I,T]);
  const w=relativeWeights.map(v=>requirePositive(v,'relative link weight'));
  assert.equal(w.length,edges.length);
  const resistance=w.reduce((a,b)=>a.add(f(1).div(b)),f(0)),bareWeight=w[0].add(w.at(-1));
  const normalizer=resistance.mul(bareWeight).div(4),A=graphCost(edges,w.map(x=>x.mul(gain)));
  const bare=A.slice(0,2).map(r=>r.slice(0,2)),effective=schurRoot(A);
  const reading={bare_trace:scalarReal(trace(bare)),effective_trace:scalarReal(trace(effective)),normalizer,relative_weights:w};
  return {...reading,normalized_chi:normalizeReading(reading)};
}
function determinant(A){A=N.matrix(A);let out=Cut.of(1);for(let j=0;j<A.length;j++){let k=j;while(k<A.length&&A[k][j].zero())k++;if(k===A.length)return Cut.of(0);if(k!==j){[A[j],A[k]]=[A[k],A[j]];out=out.neg();}const pivot=A[j][j];out=out.mul(pivot);for(let i=j+1;i<A.length;i++){const m=A[i][j].div(pivot);for(let t=j;t<A.length;t++)A[i][t]=A[i][t].sub(m.mul(A[j][t]));}}return out;}
function spectralDen(z,chi){z=f(z);return z.pow(4).add(z.pow(3).mul(8)).add(z.pow(2).mul(20)).add(z.mul(16)).add(f(chi).mul(4));}

const values=['1/3','1/2','1','2','3'],cases=[];
for(const q of values)for(const p of values){
  const z=cell(q,p),tag=q+','+p,dual=cell(f(1).div(p),f(1).div(q));
  const raw={base:rawCycleReading(z,3,[1,1,1,1]),length2:rawCycleReading(probe(q,p,2,1),5,[1,1,1,1]),energy2:rawCycleReading(probe(q,p,1,2),'7/2',[1,1,1,1])};
  const readings=Object.fromEntries(Object.entries(raw).map(([name,reading])=>[name,normalizeReading(reading)]));
  check('shared_unknown_gain_cancels_in_each_frame:'+tag,readings.base.eq(z.chi)&&readings.length2.eq(probe(q,p,2,1).chi)&&readings.energy2.eq(probe(q,p,1,2).chi));
  const got=reconstructRational(readings);
  check('data_only_reconstruction:'+tag,got.q.eq(q)&&got.p.eq(p));
  check('held_out_rectangle_prediction:'+tag,got.predicted22.eq(probe(q,p,2,2).chi));
  check('ratio_product_reconstruction:'+tag,got.r.eq(z.r)&&got.k.eq(z.k));
  const oneAxis=lengthOnly(readings);
  check('two_length_candidates:'+tag,oneAxis.candidates.some(v=>v.q.eq(q)&&v.p.eq(p))&&oneAxis.candidates.some(v=>v.q.eq(dual.q)&&v.p.eq(dual.p)));
  check('oriented_moment_selects_product_branch:'+tag,sign(z.oriented_moment)===sign(f(1).sub(z.k)));
  for(const s of ['1/2','2','3']){
    check('entire_length_family_duality:'+tag+':'+s,probe(q,p,s,1).chi.eq(probe(dual.q,dual.p,s,1).chi));
    for(const t of ['1/2','2','3']){
      const a=probe(q,p,s,t),Y=f(4).div(a.amp);
      const expected=z.r.mul(f(s).pow(2)).add(f(1).div(z.r.mul(f(s).pow(2)))).add(z.k.mul(f(t).pow(2))).add(f(1).div(z.k.mul(f(t).pow(2))));
      check('separable_response:'+tag+':'+s+','+t,Y.eq(expected));
    }
  }
  const L=cost(z);
  for(const t of [1,2]){
    const shifted=N.add(L,N.scale(N.identity(8),t)),D=spectralDen(t,z.chi),c=f(t).add(2),num=c.mul(c.pow(2).sub(2));
    check('full_characteristic_determinant:'+tag+':'+t,determinant(shifted).eq(D.pow(2)));
    const read=N.inverse(shifted).slice(0,2).map(row=>row.slice(0,2));
    check('root_resolvent_depends_only_on_chi:'+tag+':'+t,eq(read,N.scale(I,num.div(D))));
  }
  cases.push({q:z.q,p:z.p,raw_readings:raw,readings,reconstructed:got,length_only:oneAxis,oriented_moment:z.oriented_moment});
}
const centreCases=[];
for(const sigma of ['1/2','1','2','3'])for(const tau of ['1/2','1','2','3']){
  const a=f(sigma),b=f(tau),q=a.mul(b),p=b.div(a),z=cell(q,p);
  const X=a.sub(f(1).div(a)).div(2),Y=b.sub(f(1).div(b)).div(2),Phi=X.pow(2).add(Y.pow(2));
  check('exact_centered_circle:'+sigma+','+tau,z.chi.eq(f(1).div(f(1).add(Phi).pow(2))));
  check('unique_selected_centre:'+sigma+','+tau,z.chi.eq(1)===(a.eq(1)&&b.eq(1)));
  centreCases.push({sigma:a,tau:b,q,p,X,Y,Phi,chi:z.chi});
}
const sensitivity=N.matrix([[slope.neg(),slope],[slope.neg(),slope.neg()]]);
check('two_probe_sensitivity_rank_at_cut',N.rank(sensitivity)===2&&determinant(sensitivity).eq('4718592/9765625'));

const example=cases.find(x=>x.q.eq(2)&&x.p.eq(3));
const q=f(2),p=f(3),dual=cell('1/3','1/2'),ordinary=cell(2,3);
control('all_length_invariants_leave_product_duality',ordinary.chi.eq(dual.chi)&&!ordinary.k.eq(dual.k)&&!eq(ordinary.H,dual.H));
control('independent_energy_probe_breaks_that_duality',!probe(2,3,1,2).chi.eq(probe('1/3','1/2',1,2).chi));
control('exact_two_cut_compatibility_is_not_preserved_under_probe',!eq(probe(1,1,2,1).H,N.scale(I,-1)));
let rejected=false;try{reconstructRational({base:f('16/25'),length2:f('256/841'),energy2:f('256/841')});}catch(error){rejected=error.message.includes('constant-calibration');}
control('inconsistent_reading_triple_rejected',rejected);
let irrationalRejected=false;try{sqrtExact(2);}catch{irrationalRejected=true;}
control('rational_replay_does_not_approximate_irrational_roots',irrationalRejected);
const mixed=probe(q.mul('11/10'),p,2,2);
control('mixed_coupling_fails_held_out_rectangle',!mixed.chi.eq(example.reconstructed.predicted22));
// A correction vanishing on the four tested settings is not excluded globally.
const hiddenCorrection=(s,t)=>f(1).add(f(s).sub(1).mul(f(s).sub(2)).mul(f(t).sub(1)).mul(f(t).sub(2)).div(100));
const passesFour=[1,2].every(s=>[1,2].every(t=>probe(q.mul(hiddenCorrection(s,t)),p,s,t).chi.eq(probe(q,p,s,t).chi)));
control('four_frame_pass_is_not_global_physical_validation',passesFour&&!probe(q.mul(hiddenCorrection(3,3)),p,3,3).chi.eq(probe(q,p,3,3).chi));

const weighted=rawCycleReading(ordinary,'9/2',[1,2,3,4]);
const refined=rawCycleReading(ordinary,3,[2,2,2,2,2,2,2,2],true);
check('unequal_weight_graph_normalization',weighted.normalizer.eq('125/48')&&weighted.normalized_chi.eq(ordinary.chi));
check('subdivision_preserves_normalized_invariant',refined.normalizer.eq(4)&&refined.normalized_chi.eq(ordinary.chi));
control('independent_detector_gains_need_a_scale_record',!normalizeReading({...example.raw_readings.base,effective_trace:example.raw_readings.base.effective_trace.mul(2)}).eq(ordinary.chi));
control('old_graph_normalizer_fails_after_subdivision',!normalizeReading({...refined,normalizer:f(2)}).eq(ordinary.chi));

// Calibrations can now be reconstructed when physical reference readings exist.
const reference={ell:f(2),E:f(3),A:f(5),B:f(7)};
const alpha=example.reconstructed.q.mul(reference.A).div(reference.E.mul(reference.ell));
const beta=example.reconstructed.p.mul(reference.ell).div(reference.B.mul(reference.E));
check('physical_calibration_reconstruction',alpha.eq('5/3')&&beta.eq('2/7'));
const ell2=reference.ell.mul(5),E2=reference.E.mul(7),alpha2=alpha.div(35),beta2=beta.mul(5).div(7);
const q2=alpha2.mul(E2).mul(ell2).div(reference.A),p2=beta2.mul(reference.B).mul(E2).div(ell2);
control('all_relative_probes_leave_absolute_calibration_family',q2.eq(q)&&p2.eq(p)&&!ell2.eq(reference.ell)&&!E2.eq(reference.E));

const output={schema:'clock-free-scale-compass.v1',status:'PASS_NATIVE_SCALE_COMPASS',
 scope:'Exact inverse-observation protocol for the declared finite native model; no empirical quantum-gravity or absolute-constant prediction.',
 assumptions:['Positive native q,p','Known positive length and source-energy ratios s,t','A,B,alpha,beta and the transport/observer contract remain fixed during probes','q(s,t)=s*t*q; p(s,t)=t*p/s','Bare and Schur-root response readings share one positive unknown gain within each frame; relative link weights are known','The probes may leave the exactly compatible sector; their defects are retained'],
 presentations,certificates,checks,negative_controls:controls,cases,centred_circle_cases:centreCases,
 formulas:{inverse_amplitude:'Y(s,t)=4/sqrt(chi(s,t))=r*s^2+1/(r*s^2)+k*t^2+1/(k*t^2)',r:'q/p',k:'q*p',
  reconstruction:'delta_L=(Y(2,1)-Y(1,1))/3; delta_E=(Y(1,2)-Y(1,1))/3; r=(delta_L+sqrt(delta_L^2+1))/2; k=(delta_E+sqrt(delta_E^2+1))/2; q=sqrt(r*k); p=sqrt(k/r)',
  held_out:'Y(2,2)=Y(2,1)+Y(1,2)-Y(1,1)',
  centre:'s_star^2=1/r; t_star^2=1/k; q_star=p_star=1; chi_star=1',
  circle:'X=(sigma-1/sigma)/2; Y=(tau-1/tau)/2; Phi=X^2+Y^2; chi=1/(1+Phi)^2',
  root_resolvent:'(t+2)*(t^2+4*t+2)/(t^4+8*t^3+20*t^2+16*t+4*chi)',
  characteristic:'det(L+t*I)=(t^4+8*t^3+20*t^2+16*t+4*chi)^2'},
 example,normalization:{formula:'chi=((sum 1/w_relative)*(w_first_relative+w_last_relative)/4)*(tr K_eff / tr K_bare)',weighted,refined},cut_sensitivity:{matrix:sensitivity,determinant:determinant(sensitivity)},
 physical_reference:{...reference,alpha,beta,interpretation:'Illustrative exact reference readings, not empirical data'},
 summary:{symbolic_certificates:certificates.length,serialized_replays:certificates.length,exact_checks:checks.length,negative_controls:controls.length,parameter_pairs:cases.length,circle_cases:centreCases.length}
};
const serialized=JSON.stringify(output,null,2)+'\n',out=path.join(root,'SCALE_COMPASS_RESULT.json');
if(process.argv.includes('--check'))assert.equal(fs.readFileSync(out,'utf8'),serialized,'Recorded output differs from exact native replay');else fs.writeFileSync(out,serialized);
console.log(JSON.stringify({status:output.status,...output.summary,example:output.example,cut_sensitivity:output.cut_sensitivity},null,2));
