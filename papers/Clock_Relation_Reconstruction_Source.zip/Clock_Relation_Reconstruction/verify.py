"""Python 3.12 integrity and orchestration; native Node owns mathematical arithmetic."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys


def require(ok: bool, message: str) -> None:
    if not ok:
        raise SystemExit(message)


require(sys.version_info[:2] == (3, 12), "This packet requires Python 3.12.")
root = Path(__file__).resolve().parent
for folder in (".", "parent", "parent/parent", "parent/parent/parent", "parent/parent/parent/baseline"):
    base = root / folder
    manifest = json.loads((base / "MANIFEST.json").read_text())
    for item in manifest["files"]:
        path = base / item["path"]
        require(path.is_file(), "Missing file: " + str(path.relative_to(root)))
        require(hashlib.sha256(path.read_bytes()).hexdigest() == item["sha256"],
                "Integrity mismatch: " + str(path.relative_to(root)))

sources = root / "parent/parent/parent"
for pin in json.loads((sources / "SOURCE_PINS.json").read_text())["records"]:
    if "git_blob_sha1" not in pin:
        continue
    data = (sources / pin["path"]).read_bytes()
    blob = b"blob " + str(len(data)).encode("ascii") + b"\0" + data
    require(hashlib.sha1(blob).hexdigest() == pin["git_blob_sha1"],
            "Upstream source mismatch: " + pin["path"])

baseline = sources / "baseline"
for pin in json.loads((baseline / "LOCAL_SOURCE_PINS.json").read_text())["records"]:
    data = (baseline / pin["local_path"]).read_bytes()
    require(hashlib.sha256(data).hexdigest() == pin["sha256"],
            "Native engine changed: " + pin["local_path"])

subprocess.run(["node", str(root / "verify_clock_relations.cjs"), "--check"],
               check=True, cwd=root)
print("All manifests, inherited source pins and native clock-relation replay passed.")
