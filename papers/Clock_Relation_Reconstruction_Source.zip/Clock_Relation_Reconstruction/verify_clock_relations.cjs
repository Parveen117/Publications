'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const assert=require('node:assert/strict'),root=__dirname;
const baseline='parent/parent/parent/baseline';
for(const pin of JSON.parse(fs.readFileSync(path.join(root,baseline,'LOCAL_SOURCE_PINS.json'))).records)
  assert.equal(crypto.createHash('sha256').update(fs.readFileSync(path.join(root,baseline,pin.local_path))).digest('hex'),pin.sha256,pin.local_path);
const N=require('./parent/parent/parent/baseline/native/core/native_operator.cjs');
const M=require('./parent/parent/parent/baseline/native/core/paninian_operator.cjs');
const {F,Cut,IOTA}=N,f=x=>F.of(x),I=N.identity(2);
const R=N.matrix([[0,-1],[1,0]]),K=N.matrix([[0,1],[1,0]]);
const mm=(...xs)=>xs.reduce((a,b)=>N.mul(a,b)),adj=N.dagger;
const checks=[],controls=[],certificates=[],presentations=[];
const check=(name,ok,detail={})=>{assert.ok(ok,name);checks.push({name,passed:true,...detail});};
const control=(name,ok,detail={})=>{assert.ok(ok,name);controls.push({name,false_inference_rejected:true,...detail});};
const positive=x=>{x=f(x);assert.ok(!x.le(0),'Positive native scalar required');return x;};
const real=x=>{assert.ok(x.turn.zero());return x.rad;};
const inv=x=>f(1).div(x);
const trace=A=>A.reduce((z,row,i)=>z.add(row[i]),Cut.of(0));
function integerRoot(n){
  n=f(n);assert.ok(n.d===1n&&!n.le(-1));if(n.zero())return f(0);
  let bit=f(1),answer=f(0);
  while(bit.pow(2).le(n))bit=bit.mul(2);
  while(!bit.eq(1)){bit=bit.div(2);const trial=answer.add(bit);if(trial.pow(2).le(n))answer=trial;}
  assert.ok(answer.pow(2).eq(n),'Non-rational root: retain a native real-completion root');return answer;
}
function sqrtExact(x){x=f(x);assert.ok(!x.le(0)||x.zero());return integerRoot(f(x.n)).div(integerRoot(f(x.d)));}
function determinant(A){
  A=N.matrix(A);let z=Cut.of(1);
  for(let j=0;j<A.length;j++){
    let k=j;while(k<A.length&&A[k][j].zero())k++;if(k===A.length)return Cut.of(0);
    if(k!==j){[A[j],A[k]]=[A[k],A[j]];z=z.neg();}
    const pivot=A[j][j];z=z.mul(pivot);
    for(let i=j+1;i<A.length;i++){const m=A[i][j].div(pivot);for(let t=j;t<A.length;t++)A[i][t]=A[i][t].sub(m.mul(A[j][t]));}
  }return z;
}
function cell(q,p){
  q=positive(q);p=positive(p);
  const U=N.cayley(R,q),V=N.cayley(N.scale(K,IOTA),p),H=mm(adj(V),adj(U),V,U);
  const defect=N.sub(H,I),norm=mm(adj(defect),defect),chi=real(norm[0][0]).div(4);
  assert.ok(N.equal(norm,N.scale(I,chi.mul(4))));
  return {q,p,U,V,H,chi};
}
function rawReading(q,p,gain){
  const c=cell(q,p),S=N.zeros(8),edges=[c.U,c.V,adj(c.U),adj(c.V)];
  edges.forEach((T,k)=>{for(let i=0;i<2;i++)for(let j=0;j<2;j++)S[2*((k+1)%4)+i][2*k+j]=T[i][j];});
  const L=N.scale(N.sub(N.scale(N.identity(8),2),N.add(S,adj(S))),positive(gain));
  const bare=L.slice(0,2).map(row=>row.slice(0,2)),X=L.slice(0,2).map(row=>row.slice(2)),interior=L.slice(2).map(row=>row.slice(2));
  const effective=N.sub(bare,mm(X,N.inverse(interior),adj(X)));
  const bare_trace=real(trace(bare)),effective_trace=real(trace(effective)),chi=effective_trace.mul(2).div(bare_trace);
  assert.ok(chi.eq(c.chi));
  return {bare_trace,effective_trace,normalizer:f(2),chi};
}
function response(chi){chi=positive(chi);assert.ok(chi.le(1));return f(4).div(sqrtExact(chi));}
function factors(s,t){s=positive(s);t=positive(t);const A=s.pow(2),B=t.pow(2);return [A,inv(A),B,inv(B)];}
function observer(lambda){return N.matrix(Array.from({length:4},(_,j)=>lambda.map(x=>x.pow(j))));}
function advanceDiagonal(lambda){return N.matrix(lambda.map((x,i)=>lambda.map((_,j)=>i===j?x:f(0))));}
function evaluate(c,lambda,j){return c.reduce((out,x,i)=>out.add(x.mul(lambda[i].pow(j))),f(0));}
function validateCoefficients(c){
  assert.ok(c.every(x=>!x.le(0)),'Recovered coefficients must be positive');
  assert.ok(c[0].mul(c[1]).eq(1)&&c[2].mul(c[3]).eq(1),'Recovered coefficients violate reciprocal constraints');
  return {r:c[0],k:c[2],q:sqrtExact(c[0].mul(c[2])),p:sqrtExact(c[2].div(c[0]))};
}
// The decoder receives four normalized observations and known relative steps.
// It never receives the generating q or p.
function decode(chis,s,t){
  assert.equal(chis.length,4);const lambda=factors(s,t),O=observer(lambda);
  assert.equal(N.rank(O),4,'Calibrated comparison scan does not separate four linear modes');
  const Y=chis.map(response),c=mm(N.inverse(O),N.matrix(Y.map(x=>[x]))).map(row=>real(row[0]));
  const params=validateCoefficients(c),Y4=evaluate(c,lambda,4);
  return {...params,coefficients:c,Y,predicted_Y4:Y4,predicted_chi4:f(16).div(Y4.pow(2))};
}
function commutative(tokens,name){
  const rules=[];for(let j=1;j<tokens.length;j++)for(let i=0;i<j;i++)rules.push({id:tokens[j]+'_'+tokens[i],lhs:[tokens[j],tokens[i]],rhs:[[[tokens[i],tokens[j]],1]],source:'Declared real central native comparison coefficients'});
  const S=new M.Presentation({tokens,rules}),w=Object.fromEntries(tokens.map(x=>[x,S.word([x])]));
  const audit=S.audit(),star=M.daggerGate(S,w);
  check(name+':confluence',audit.status==='CONFLUENT_BY_CHECKED_DIAMONDS');check(name+':dagger',star.status==='DAGGER_DESCENDS');
  presentations.push({name,spec:S.spec(),audit,dagger_status:star.status});return {S,w};
}
function prove(S,name,lhs,rhs){
  const p=M.proveEquality(lhs,rhs);check(name,p.status==='EQUAL_IN_DECLARED_QUOTIENT');
  const certificate=JSON.parse(JSON.stringify(p.certificate));check(name+':serialized_replay',S.replay(certificate)===true);certificates.push({name,certificate});
}
const times=(...xs)=>xs.reduce((a,b)=>a.times(b));
function power(x,n){let y=x.system.one();for(let j=0;j<n;j++)y=y.times(x);return y;}
const sq=x=>power(x,2);

const T=commutative(['q','p','a','b'],'delay_period_response'),{q,p,a,b}=T.w;
prove(T.S,'delay_period_inverse_amplitude',sq(b).plus(sq(q.times(a))).times(sq(a.times(b)).plus(sq(p))),
  times(sq(a),power(b,4)).plus(times(sq(p),sq(b))).plus(times(sq(q),power(a,4),sq(b))).plus(times(sq(q),sq(p),sq(a))));
// Existing Cayley algebra is an explicit boundary on any physical phase adapter.
// A parameter proportional to frequency*duration is not itself an additive phase.
const tOne=T.S.one(),cayleyNum=q.plus(p),cayleyDen=tOne.minus(q.times(p));
prove(T.S,'cayley_composition_denominator',sq(cayleyDen).plus(sq(cayleyNum)),tOne.plus(sq(q)).times(tOne.plus(sq(p))));
prove(T.S,'cayley_composition_identity_part',sq(cayleyDen).minus(sq(cayleyNum)),tOne.minus(sq(q)).times(tOne.minus(sq(p))).minus(q.times(p).scale(4)));
prove(T.S,'cayley_composition_turn_part',cayleyNum.times(cayleyDen).scale(2),q.times(tOne.minus(sq(p))).plus(p.times(tOne.minus(sq(q)))).scale(2));

const V=commutative(['l0','l1','l2','l3'],'four_mode_observer'),ls=Object.values(V.w);
function perms(xs){if(!xs.length)return [[]];return xs.flatMap((x,i)=>perms(xs.filter((_,j)=>j!==i)).map(t=>[x,...t]));}
let detExpr=V.S.zero();
for(const perm of perms([0,1,2,3])){
  let sign=1;for(let i=0;i<4;i++)for(let j=i+1;j<4;j++)if(perm[i]>perm[j])sign=-sign;
  detExpr=detExpr.plus(times(...perm.map((col,row)=>power(ls[col],row))).scale(sign));
}
let product=V.S.one();for(let i=0;i<4;i++)for(let j=i+1;j<4;j++)product=product.times(ls[j].minus(ls[i]));
prove(V.S,'native_four_readout_determinant',detExpr,product);

const P=commutative(['A','B','z'],'reciprocal_annihilator'),{A,B,z}=P.w,one=P.S.one();
const AB=A.times(B),sum=sq(A).plus(one).times(B).plus(sq(B).plus(one).times(A));
const middle=sq(A).plus(one).times(sq(B).plus(one)).plus(AB.scale(2));
const factor=times(z.minus(A),A.times(z).minus(one),z.minus(B),B.times(z).minus(one));
const expanded=AB.times(power(z,4)).minus(sum.times(power(z,3))).plus(middle.times(sq(z))).minus(sum.times(z)).plus(AB);
prove(P.S,'reciprocal_four_mode_annihilator',factor,expanded);

const C=commutative(['x0','x1','y0','y1','g','o'],'shared_affine_clock'),w=C.w;
const dx=w.x1.minus(w.x0),dy=w.y1.minus(w.y0);
const tx=w.g.times(w.x1).plus(w.o).minus(w.g.times(w.x0).plus(w.o));
const ty=w.g.times(w.y1).plus(w.o).minus(w.g.times(w.y0).plus(w.o));
prove(C.S,'shared_affine_clock_ratio',tx.times(dy),ty.times(dx));

const lambda=factors(2,4),O=observer(lambda),D=advanceDiagonal(lambda),seed=N.matrix([[1,1,1,1]]),closure=N.rowClosure(seed,[D]);
check('known_step_observer_is_four_dimensional',closure.rank===4&&closure.extra===3&&JSON.stringify(closure.ranks)==='[1,2,3,4]');
check('successive_observer_rows_match',N.equal(O,N.matrix([0,1,2,3].map(j=>mm(seed,N.power(D,j))[0]))));
const aSum=lambda[0].add(lambda[1]),bSum=lambda[2].add(lambda[3]),S=aSum.add(bSum),Tcoef=aSum.mul(bSum).add(2);
const polynomial=N.add(N.sub(N.add(N.sub(N.power(D,4),N.scale(N.power(D,3),S)),N.scale(N.power(D,2),Tcoef)),N.scale(D,S)),N.identity(4));
check('native_scan_operator_obeys_quartic',N.isZero(polynomial));
check('specific_recurrence_coefficients',S.eq('325/16')&&Tcoef.eq('4497/64'));
let factorDet=f(1);for(let i=0;i<4;i++)for(let j=i+1;j<4;j++)factorDet=factorDet.mul(lambda[j].sub(lambda[i]));
check('specific_observer_determinant',determinant(O).eq(factorDet));
const phaseProduct=mm(N.cayley(R,'1/2'),N.cayley(R,'1/3'));
check('native_cayley_composition_is_fractional',N.equal(phaseProduct,N.cayley(R,1)));
control('linear_cayley_parameter_is_not_additive_physical_phase',!N.equal(phaseProduct,N.cayley(R,'5/6')));

const cases=[];
function runCase(q,p,s,t,tag){
  q=positive(q);p=positive(p);s=positive(s);t=positive(t);
  const readings=[];
  for(let j=0;j<5;j++)readings.push(rawReading(q.mul(s.mul(t).pow(j)),p.mul(t.div(s).pow(j)),f(j).add(2)));
  const recovered=decode(readings.slice(0,4).map(x=>x.chi),s,t),l=factors(s,t);
  check('data_only_transport_recovery:'+tag,recovered.q.eq(q)&&recovered.p.eq(p));
  check('held_out_fifth_prediction:'+tag,recovered.predicted_chi4.eq(readings[4].chi));
  const Y=readings.map(x=>response(x.chi)),sum1=l[0].add(l[1]).add(l[2]).add(l[3]),sum2=l[0].add(l[1]).mul(l[2].add(l[3])).add(2);
  const recurrence=sum1.mul(Y[3]).sub(sum2.mul(Y[2])).add(sum1.mul(Y[1])).sub(Y[0]);
  check('fifth_recurrence:'+tag,recurrence.eq(Y[4]));
  const c=[q.div(p),p.div(q),q.mul(p),inv(q.mul(p))];
  check('positive_reciprocal_coefficients:'+tag,recovered.coefficients.every((x,i)=>x.eq(c[i])));
  for(let j=0;j<5;j++)check('four_mode_readout:'+tag+':'+j,evaluate(c,l,j).eq(Y[j]));
  const entry={q,p,length_step:s,energy_step:t,readings,Y,recovered};cases.push(entry);return entry;
}
for(const q of ['1/3','1/2','1','2','3'])for(const p of ['1/3','1/2','1','2','3'])runCase(q,p,2,4,q+','+p);
runCase(2,3,2,3,'alternative_steps_2_3');runCase(2,3,'3/2',2,'alternative_steps_3over2_2');

const degenerate=[];
for(const setting of [
  {name:'length_only',s:2,t:1,rank:3,q2:'1/3',p2:'1/2'},
  {name:'energy_only',s:1,t:2,rank:3,q2:3,p2:2},
  {name:'equal_length_energy_rates',s:2,t:2,rank:2,q2:2,p2:'1/3'},
  {name:'reciprocal_length_energy_rates',s:2,t:'1/2',rank:2,q2:'1/2',p2:3},
  {name:'unchanged_source_and_length',s:1,t:1,rank:1,q2:3,p2:2}
]){
  const s=f(setting.s),t=f(setting.t),rank=N.rank(observer(factors(s,t)));
  const matches=[0,1,2,3,4].every(j=>cell(f(2).mul(s.mul(t).pow(j)),f(3).mul(t.div(s).pow(j))).chi.eq(cell(f(setting.q2).mul(s.mul(t).pow(j)),f(setting.p2).mul(t.div(s).pow(j))).chi));
  control(setting.name+'_has_global_ambiguity',matches&&rank===setting.rank);
  degenerate.push({...setting,rank});
}

const forged=[f('2/3'),f('3/2'),f(6),f('1/5')],forgedY=Array.from({length:5},(_,j)=>evaluate(forged,lambda,j));
let rejected=false;try{decode(forgedY.slice(0,4).map(y=>f(16).div(y.pow(2))),2,4);}catch(e){rejected=e.message.includes('reciprocal');}
control('positive_but_nonreciprocal_coefficients_rejected',rejected);
control('recurrence_alone_does_not_validate_native_cell',S.mul(forgedY[3]).sub(Tcoef.mul(forgedY[2])).add(S.mul(forgedY[1])).sub(forgedY[0]).eq(forgedY[4])&&rejected);
let negativeRejected=false;try{validateCoefficients([f(-1),f(-1),f(6),f('1/6')]);}catch(e){negativeRejected=e.message.includes('positive');}
control('negative_coefficients_rejected',negativeRejected);
let rootRejected=false;try{sqrtExact(2);}catch{rootRejected=true;}
control('no_irrational_float_fallback',rootRejected);
const example=cases.find(x=>x.q.eq(2)&&x.p.eq(3)&&x.length_step.eq(2)&&x.energy_step.eq(4));
const disturbed=cell(f(2).mul(f(8).pow(4)).mul('11/10'),f(3).mul(f(2).pow(4))).chi;
control('fifth_frame_calibration_drift_rejected',!disturbed.eq(example.recovered.predicted_chi4));

const delay=f(3),phaseTime=f(5),alpha=f('7/11'),zeta=f('13/17');
const pq=alpha.mul(delay).div(phaseTime),pp=zeta.div(delay.mul(phaseTime));
const physicalCase=runCase(pq,pp,2,4,'illustrative_time_reference');
const inferredAlpha=physicalCase.recovered.q.mul(phaseTime).div(delay),inferredZeta=physicalCase.recovered.p.mul(delay).mul(phaseTime);
check('time_only_physical_adapter_calibration',inferredAlpha.eq(alpha)&&inferredZeta.eq(zeta));
const gain=f(7),offset=f(11),clock=x=>gain.mul(x).add(offset);
const delaySeen=clock(f(13)).sub(clock(f(10))),phaseSeen=clock(f(25)).sub(clock(f(20)));
check('common_affine_clock_preserves_alpha',physicalCase.recovered.q.mul(phaseSeen).div(delaySeen).eq(alpha));
check('time_squared_record_tracks_clock_gain',physicalCase.recovered.p.mul(delaySeen).mul(phaseSeen).eq(zeta.mul(gain.pow(2))));
control('separate_clock_gains_need_a_ratio_record',!physicalCase.recovered.q.mul(phaseSeen.mul(2)).div(delaySeen).eq(alpha));
const hiddenN=f(2),qWithN=alpha.mul(hiddenN).mul(delay).div(phaseTime);
control('unrecorded_photon_number_confounds_alpha',qWithN.mul(phaseTime).div(delay).eq(alpha.mul(hiddenN))&&!qWithN.mul(phaseTime).div(delay).eq(alpha));
const beta=f('2/3'),planckTimeSquared=zeta.div(beta),betaAlt=beta.mul(5),planckAlt=planckTimeSquared.div(5);
control('gravity_calibration_and_planck_time_remain_a_product',betaAlt.mul(planckAlt).eq(zeta)&&!betaAlt.eq(beta));

const circleCases=[];
for(const sigma of ['1/2','1','2','3'])for(const eta of ['1/2','1','2','3']){
  const d=f(sigma),h=f(eta),c=cell(d.div(h),inv(d.mul(h))),X=d.sub(inv(d)).div(2),Z=h.sub(inv(h)).div(2),Phi=X.pow(2).add(Z.pow(2));
  check('delay_period_circle:'+sigma+','+eta,c.chi.eq(inv(f(1).add(Phi).pow(2))));circleCases.push({sigma:d,eta:h,X,Z,Phi,chi:c.chi});
}
const rectangleRank=N.rank(N.matrix([[1,1,1,1],[4,'1/4',1,1],[1,1,4,'1/4']]));
control('rank_four_is_sufficient_not_globally_necessary',rectangleRank===3);

const output={schema:'clock-relation-reconstruction.v1',status:'PASS_NATIVE_CLOCK_RELATIONS',
 scope:'Native inverse observation theorem with explicitly imported photon and vacuum-flight dictionary; exact synthetic tests, not a gravitational experiment.',
 assumptions:['Positive q,p','Known positive relative length/energy step factors s,t','Fixed transport calibration throughout each scan','Normalized root responses use the inherited shared-gain and known-relative-weight contract','Four modes s^2,s^-2,t^2,t^-2 must be distinct for the linear four-reading decoder','Physical time is an optional observation adapter, not the primitive native history ledger'],
 presentations,certificates,checks,negative_controls:controls,
 scan_operator:{length_step:f(2),energy_step:f(4),phase_period_step:f('1/4'),lambda,D,observer:O,determinant:determinant(O),closure,recurrence:{S,T:Tcoef,formula:'Y[j+4]=S*Y[j+3]-T*Y[j+2]+S*Y[j+1]-Y[j]'}},
 cases,example,degenerate_protocols:degenerate,clock_circle_cases:circleCases,
 physical_example:{delay,phaseTime,q:pq,p:pp,alpha:inferredAlpha,zeta:inferredZeta,common_clock_gain:gain,common_clock_offset:offset,delaySeen,phaseSeen,interpretation:'Illustrative exact time references; zeta = beta*hbar*G/c^5, not a measured constant'},
 formulas:{delay_period_adapter:'q=alpha*Delta/Theta; p=zeta/(Delta*Theta); Theta=1/omega; Delta=ell/c; zeta=beta*hbar*G/c^5',
  general_time_ratios:'a=Delta/Delta0; b=Theta/Theta0; q_new=(a/b)*q; p_new=p/(a*b)',
  time_response:'Y(a,b)=r*a^2+1/(r*a^2)+k/b^2+b^2/k',
  four_mode_response:'Y_j=r*A^j+(1/r)*A^-j+k*B^j+(1/k)*B^-j; A=s^2; B=t^2',
  admission:'All recovered coefficients positive; c0*c1=1 and c2*c3=1',
  physical_calibration:'alpha=q*Theta/Delta; zeta=p*Delta*Theta',
  parameter_count:'Four linear comparison coordinates subject to two reciprocal constraints; rank-four is sufficient, not a universal nonlinear minimum'},
 phase_adapter:{composition:'q_join=(q1+q2)/(1-q1*q2), when denominator is nonzero',scope:'The declared linear source-action adapter q=alpha*omega*Delta is not an assertion that omega*Delta is the Cayley rotation angle.',example:{q1:'1/2',q2:'1/3',joined:'1',naive_sum:'5/6'}},
 summary:{symbolic_certificates:certificates.length,serialized_replays:certificates.length,exact_checks:checks.length,negative_controls:controls.length,synthetic_scans:cases.length,clock_circle_cases:circleCases.length}};
const serialized=JSON.stringify(output,null,2)+'\n',out=path.join(root,'CLOCK_RELATION_RESULT.json');
if(process.argv.includes('--check'))assert.equal(fs.readFileSync(out,'utf8'),serialized,'Recorded result differs from native replay');else fs.writeFileSync(out,serialized);
console.log(JSON.stringify({status:output.status,...output.summary,scan_determinant:output.scan_operator.determinant,example:output.example,physical_example:output.physical_example},null,2));
