CLOCK-RELATION RECONSTRUCTION -- version 0.5
Research development for Monty, 14 October 2026

RESULT
Known numerator/denominator changes can make one calibrated scan sufficient
to recover the two native transport parameters. For a fixed multiplicative
length step s and energy step t, four normalized readings recover positive
q,p when s!=1, t!=1, s!=t and s*t!=1. Positivity and reciprocal-coefficient
constraints are mandatory. A fifth invariant is predicted without fitting.

START HERE
Clock_Relation_Reconstruction.pdf -- eight-page proof note
CLOCK_PROTOCOL.json             -- declared contracts and source roles
CLOCK_RELATION_RESULT.json      -- native output and proof certificates
verify_clock_relations.cjs      -- native verifier and negative controls
verify.py                       -- Python 3.12 integrity/replay wrapper
parent/                         -- unchanged preceding scale-compass packet

REPRODUCE
Requires Python 3.12 and Node.js; no npm install is needed.
From the extracted folder run:

    python3.12 verify.py

Expected status: PASS_NATIVE_CLOCK_RELATIONS
  7 symbolic certificates
  7 serialized replays
  299 exact checks
  15 negative controls
  28 synthetic scans
  16 clock-circle cases

The check count includes presentation gates, certificate checks and replays;
it is not a count of independent physical experiments. The wrapper checks
all inherited manifests and source pins, then replays the new verifier with
--check and compares output byte-for-byte. It preserves, but does not rerun,
the preceding packet's entire computation.

THE OBSERVER
r=q/p, k=q*p; c=(r,1/r,k,1/k)
A=s*s, B=t*t; D=diag(A,1/A,B,1/B); C=(1,1,1,1)
Y_j=4/sqrt(chi_j)=C*D^j*c
O has rows C, C*D, C*D^2, C*D^3
det(O)=product_(i<j)(lambda_j-lambda_i)
where lambda=(A,1/A,B,1/B)

Decode c=O^-1*Y. Require all entries positive and c1*c2=c3*c4=1.
Then q=sqrt(c1*c3), p=sqrt(c3/c1).
With S=A+1/A+B+1/B and T=(A+1/A)*(B+1/B)+2,
Y_(j+4)=S*Y_(j+3)-T*Y_(j+2)+S*Y_(j+1)-Y_j.
The recurrence alone does not guarantee the reciprocal constraints.

For the example s=2,t=4:
D=diag(4,1/4,16,1/16)
det(O)=136632825/16384
S=325/16; T=4497/64
The data-only decoder recovers q=2,p=3. Its predicted fifth invariant equals
the directly constructed native loop value exactly.

TIME ADAPTER
The optional physical dictionary uses an identified photon energy
E=hbar*omega and calibrated vacuum path ell=c*Delta. Set Theta=1/omega.
Starting from the preceding proposed transport dictionary gives:
q=alpha*Delta/Theta
p=zeta/(Delta*Theta), where zeta=beta*hbar*G/c^5
Thus alpha=q*Theta/Delta and zeta=p*Delta*Theta.

A shared affine timestamp change t_seen=g*t+offset cancels from alpha.
The record zeta scales with g^2 and needs a seconds calibration to express
it in seconds squared. Unrelated clock gains require a scale-ratio record.

Theta is inverse angular frequency, not an uncertainty time or arbitrary
waiting time. For round-trip ranging Delta is the calibrated half-delay.
Unknown photon number N confounds alpha with N*alpha; changing N changes
the source-energy relation. The illustrative references are not empirical.

The source program Delta_j=2^j*Delta0, Theta_j=4^-j*Theta0 is a declared
coupled control program, not a spontaneous physical evolution law.

PHASE BOUNDARY
Cayley parameters compose as (q1+q2)/(1-q1*q2) where the denominator is
nonzero. They are not additive physical rotation angles. The linear
source-action adapter q=alpha*omega*Delta does not assert that omega*Delta
is the rotation angle of U(q). A physical phase identification needs its
own conversion and may change the assumed scan law. Three certificates
recheck the inherited Cayley identities for this boundary.

WHAT IS INHERITED / WHAT IS NEW
Inherited: native cut arithmetic, turn scalar, Cayley algebra, loop formula,
two-cut-compatible selection, scale-compass circle, stationary shared-gain
normalization and the GE2 native history ledger.
New: the inverse comparison matrix, fixed-step scan observability criterion,
fifth-reading recurrence, time-adapter calibration and scan-blindness table.
The circle in delay/phase-time coordinates is an inherited specialization.

The core remains clock-free. No physical clock is identified with the GE2
history ledger. No physical Hilbert space, new scalar engine, numerical
eigensolver or floating-point fit is introduced. The rational-root adapter
rejects non-rational roots; the written theorem uses the inherited positive
real completion. Arbitrary noisy/irrational input decoding is not supplied.

LIMITS
Rank four is sufficient for this linear recovery, not a universal minimum
number of scalar measurements. The preceding three-reading protocol remains
valid. Passing a finite number of frames does not prove a global physical
coupling law. The construction does not split beta from hbar*G/c^5 or derive
an empirical constant, spacetime dynamics or an Einstein field equation.

PRIMARY PHYSICAL SOURCES
NIST: Kilogram: Mass and Planck's Constant
https://www.nist.gov/si-redefinition/kilogram/kilogram-mass-and-plancks-constant
BIPM: SI base unit: metre (m)
https://www.bipm.org/en/si-base-units/metre
These supply only the stated physical dictionary relations. They do not
support the proposed native source coupling or the new reconstruction theorem.

BUILD THE NOTE
Run pdflatex twice on Clock_Relation_Reconstruction.tex. The delivered
manifest checks the delivered PDF bytes; a local rebuild can change them.

CANONICAL ENGINE PIN
Recognition-Kernel-Framework: e8e3089745bf7dc0532d01c62a5f660f5658c6f0
Native home: operator_foundation/
All source and engine pins remain in the unchanged inherited packets.
