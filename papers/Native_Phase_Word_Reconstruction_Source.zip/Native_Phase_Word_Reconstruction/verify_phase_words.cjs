'use strict';
// All mathematical arithmetic uses the pinned native cut engine and compiler.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const assert=require('node:assert/strict'),root=__dirname;
const baseline='parent/parent/parent/parent/baseline';
for(const pin of JSON.parse(fs.readFileSync(path.join(root,baseline,'LOCAL_SOURCE_PINS.json'))).records)
  assert.equal(crypto.createHash('sha256').update(fs.readFileSync(path.join(root,baseline,pin.local_path))).digest('hex'),pin.sha256,pin.local_path);
const N=require('./parent/parent/parent/parent/baseline/native/core/native_operator.cjs');
const M=require('./parent/parent/parent/parent/baseline/native/core/paninian_operator.cjs');
const {F,Cut,IOTA}=N,f=x=>F.of(x),I=N.identity(2);
const R=N.matrix([[0,-1],[1,0]]),K=N.matrix([[0,1],[1,0]]),J=N.scale(K,IOTA);
const mm=(...xs)=>xs.reduce((a,b)=>N.mul(a,b)),adj=N.dagger,Z=N.scale(mm(R,K),-1),iR=N.scale(R,IOTA);
const checks=[],controls=[],certificates=[],presentations=[];
const check=(name,ok,detail={})=>{assert.ok(ok,name);checks.push({name,passed:true,...detail});};
const control=(name,ok,detail={})=>{assert.ok(ok,name);controls.push({name,false_inference_rejected:true,...detail});};
const real=x=>{assert.ok(x.turn.zero(),'Real comparison required');return x.rad;};
const positive=x=>{x=f(x);assert.ok(!x.le(0),'Positive native scalar required');return x;};
const sign=x=>f(x).zero()?0:f(x).le(0)?-1:1;
const inv=x=>f(1).div(x),trace=A=>A.reduce((z,row,i)=>z.add(row[i]),Cut.of(0));
function integerRoot(n){
  n=f(n);assert.ok(n.d===1n&&!n.le(-1));if(n.zero())return f(0);
  let bit=f(1),answer=f(0);
  while(bit.pow(2).le(n))bit=bit.mul(2);
  while(!bit.eq(1)){bit=bit.div(2);const trial=answer.add(bit);if(trial.pow(2).le(n))answer=trial;}
  assert.ok(answer.pow(2).eq(n),'Non-rational root: retain a native real-completion root');return answer;
}
function sqrtExact(x){x=f(x);assert.ok(!x.le(0)||x.zero());return integerRoot(f(x.n)).div(integerRoot(f(x.d)));}
function transports(q,p){
  q=f(q);p=f(p);const U=N.cayley(R,q),V=N.cayley(J,p);
  return {q,p,U,V,a:real(U[0][0]),b:real(U[1][0]),c:real(V[0][0]),d:V[0][1].turn};
}
function loop(U,V){
  const H=mm(adj(V),adj(U),V,U),defect=N.sub(H,I),norm=mm(adj(defect),defect),chi=real(norm[0][0]).div(4);
  assert.ok(N.equal(norm,N.scale(I,chi.mul(4))),'Loop defect must be scalar');return {H,chi};
}
function moments(U,V,comparators={K,iR,Z}){
  return {wq:real(trace(mm(comparators.Z,adj(U),comparators.K,U))).div(2),
          wp:real(trace(mm(comparators.Z,adj(V),comparators.iR,V))).div(2)};
}
function rawReading(U,V,gain){
  const S=N.zeros(8),edges=[U,V,adj(U),adj(V)];
  edges.forEach((T,k)=>{for(let i=0;i<2;i++)for(let j=0;j<2;j++)S[2*((k+1)%4)+i][2*k+j]=T[i][j];});
  const L=N.scale(N.sub(N.scale(N.identity(8),2),N.add(S,adj(S))),positive(gain));
  const bare=L.slice(0,2).map(row=>row.slice(0,2)),X=L.slice(0,2).map(row=>row.slice(2)),interior=L.slice(2).map(row=>row.slice(2));
  const effective=N.sub(bare,mm(X,N.inverse(interior),adj(X)));
  const bare_trace=real(trace(bare)),effective_trace=real(trace(effective)),chi=effective_trace.mul(2).div(bare_trace);
  assert.ok(chi.eq(loop(U,V).chi));return {bare_trace,effective_trace,normalizer:f(2),chi};
}
function amplitudes(chis){
  assert.equal(chis.length,3);const [x,y,z]=chis.map(f);positive(x);
  assert.ok([x,y,z].every(v=>f(0).le(v)&&v.le(1)),'Loop reading outside [0,1]');
  const u=f(1).sub(y.div(x.mul(4))),v=f(1).sub(z.div(x.mul(4)));
  assert.ok(!u.le(0)&&u.le(1)&&!v.le(0)&&v.le(1),'Invalid recovered amplitudes');
  assert.ok(x.eq(u.mul(v)),'Three readings violate amplitude product');
  return {u,v,predicted_chi22:y.mul(z).div(x),predicted_chi31:x.mul(f(3).sub(u.mul(4)).pow(2)),
    predicted_chi13:x.mul(f(3).sub(v.mul(4)).pow(2))};
}
function signedAxis(u,epsilon){
  assert.ok([-1,0,1].includes(epsilon),'Orientation sign must be -1, 0 or 1');
  assert.ok(u.eq(1)?epsilon===0:epsilon!==0,'Orientation sign inconsistent with amplitude');
  const turn=sqrtExact(u),identity=sqrtExact(f(1).sub(u)).mul(epsilon);
  return {identity,turn,parameter:f(1).sub(identity).div(turn)};
}
// Data-only decoder: no generating q,p or continuous moment magnitude is passed.
function decode(chis,epsilonQ,epsilonP){
  const recovered=amplitudes(chis),uAxis=signedAxis(recovered.u,epsilonQ),vAxis=signedAxis(recovered.v,epsilonP);
  return {...recovered,epsilonQ,epsilonP,a:uAxis.identity,b:uAxis.turn,c:vAxis.identity,d:vAxis.turn,q:uAxis.parameter,p:vAxis.parameter};
}
function recurrence(a,b,n){let before=f(0),current=b;if(n===0)return before;for(let j=1;j<n;j++){const next=a.mul(2).mul(current).sub(before);before=current;current=next;}return current;}
function presentation(tokens,name,extra=[]){
  const rules=[];for(let j=1;j<tokens.length;j++)for(let i=0;i<j;i++)rules.push({id:tokens[j]+'_'+tokens[i],lhs:[tokens[j],tokens[i]],rhs:[[[tokens[i],tokens[j]],1]],source:'Declared real central native comparison coefficients'});
  const S=new M.Presentation({tokens,rules:rules.concat(extra)}),w=Object.fromEntries(tokens.map(x=>[x,S.word([x])]));
  const audit=S.audit(),star=M.daggerGate(S,w);
  check(name+':confluence',audit.status==='CONFLUENT_BY_CHECKED_DIAMONDS');check(name+':dagger',star.status==='DAGGER_DESCENDS');
  presentations.push({name,spec:S.spec(),audit,dagger_status:star.status});return {S,w};
}
function prove(S,name,lhs,rhs){
  const p=M.proveEquality(lhs,rhs);check(name,p.status==='EQUAL_IN_DECLARED_QUOTIENT');
  const certificate=JSON.parse(JSON.stringify(p.certificate));check(name+':serialized_replay',S.replay(certificate)===true);certificates.push({name,certificate});
}
const times=(...xs)=>xs.reduce((a,b)=>a.times(b)),sq=x=>x.times(x);
const C=presentation(['a','b','c','d'],'native_unit_pairs',[
  {id:'b_square',lhs:['b','b'],rhs:[[[],1],[['a','a'],-1]],source:'a^2+b^2=1 from native Cayley unitarity'},
  {id:'d_square',lhs:['d','d'],rhs:[[[],1],[['c','c'],-1]],source:'c^2+d^2=1 from native Cayley unitarity'}]);
const {a,b,c,d}=C.w,one=C.S.one(),zero=C.S.zero();
const smul=(A,B)=>A.map(row=>B[0].map((_,j)=>row.reduce((z,x,k)=>z.plus(x.times(B[k][j])),zero)));
const smm=(...xs)=>xs.reduce(smul),sscale=(A,s)=>A.map(row=>row.map(x=>x.times(s)));
const sadd=(A,B)=>A.map((row,i)=>row.map((x,j)=>x.plus(B[i][j])));
const ssub=(A,B)=>A.map((row,i)=>row.map((x,j)=>x.minus(B[i][j])));
const sconst=A=>A.map(row=>row.map(x=>one.scale(x)));
const sI=sconst(I),sR=sconst(R),sK=sconst(K),sJ=sconst(J),sZ=sconst(Z),siR=sconst(iR);
const sU=sadd(sscale(sI,a),sscale(sR,b)),sUd=ssub(sscale(sI,a),sscale(sR,b));
const sV=sadd(sscale(sI,c),sscale(sJ,d)),sVd=ssub(sscale(sI,c),sscale(sJ,d));
const sH=smm(sVd,sUd,sV,sU),sHd=smm(sUd,sVd,sU,sV);
const expanded=sadd(sadd(sscale(sI,one.minus(sq(b).times(sq(d)).scale(2))),sscale(sR,times(a,b,sq(d)).scale(2))),
  sadd(sscale(sJ,times(sq(b),c,d).scale(-2)),sscale(smul(sR,sJ),times(a,b,c,d).scale(-2))));
for(let i=0;i<2;i++)for(let j=0;j<2;j++)prove(C.S,'commutator_expansion_'+i+j,sH[i][j],expanded[i][j]);
const defect=smm(ssub(sHd,sI),ssub(sH,sI));
for(let i=0;i<2;i++)for(let j=0;j<2;j++)prove(C.S,'loop_factorization_'+i+j,defect[i][j],i===j?sq(b).times(sq(d)).scale(4):zero);
const strace=A=>A[0][0].plus(A[1][1]);
prove(C.S,'phase_insensitive_q_orientation',strace(smm(sZ,sUd,sK,sU)).scale('1/2'),a.times(b).scale(2));
prove(C.S,'phase_insensitive_p_orientation',strace(smm(sZ,sVd,siR,sV)).scale('1/2'),c.times(d).scale(2));
prove(C.S,'double_word_amplitude',sq(a.times(b).scale(2)),sq(b).times(one.minus(sq(b))).scale(4));
prove(C.S,'triple_word_amplitude',sq(sq(a).times(b).scale(4).minus(b)),sq(b).times(sq(one.scale(3).minus(sq(b).scale(4)))));
const E=presentation(['q','g','e'],'phase_continuation_jet',[
  {id:'first_order_jet',lhs:['e','e'],rhs:[],source:'First-order native comparison jet; e^2=0'}]);
const {q:qE,g,e}=E.w;
prove(E.S,'additive_source_forces_cayley_riccati_jet',qE.plus(g.times(E.S.one().plus(sq(qE))).times(e)).times(E.S.one().minus(times(qE,g,e))),qE.plus(g.times(e)));

const cases=[];
function runCase(q,p){
  const T=transports(positive(q),positive(p)),W=moments(T.U,T.V),readings=[
    rawReading(T.U,T.V,2),rawReading(N.power(T.U,2),T.V,3),rawReading(T.U,N.power(T.V,2),5)];
  const rec=decode(readings.map(r=>r.chi),sign(W.wq),sign(W.wp)),tag=q+','+p;
  check('data_only_positive_chart_recovery:'+tag,rec.q.eq(q)&&rec.p.eq(p));
  check('orientation_moment_and_amplitude:'+tag,W.wq.eq(T.a.mul(T.b).mul(2))&&W.wp.eq(T.c.mul(T.d).mul(2))&&W.wq.pow(2).eq(rec.u.mul(f(1).sub(rec.u)).mul(4))&&W.wp.pow(2).eq(rec.v.mul(f(1).sub(rec.v)).mul(4)));
  const heldout=rawReading(N.power(T.U,2),N.power(T.V,2),7);
  check('held_out_double_double:'+tag,rec.predicted_chi22.eq(heldout.chi));
  check('held_out_triple_words:'+tag,rec.predicted_chi31.eq(loop(N.power(T.U,3),T.V).chi)&&rec.predicted_chi13.eq(loop(T.U,N.power(T.V,3)).chi));
  const grid=[],recipQ=transports(inv(q),p),recipP=transports(q,inv(p));
  for(let m=1;m<=4;m++)for(let n=1;n<=4;n++){
    const Um=N.power(T.U,m),Vn=N.power(T.V,n),chi=loop(Um,Vn).chi;
    const bm=recurrence(rec.a,rec.b,m),dn=recurrence(rec.c,rec.d,n);
    check('native_word_recurrence:'+tag+':'+m+','+n,chi.eq(bm.pow(2).mul(dn.pow(2))));
    check('integer_words_are_reciprocal_blind:'+tag+':'+m+','+n,chi.eq(loop(N.power(recipQ.U,m),N.power(recipQ.V,n)).chi)&&chi.eq(loop(N.power(recipP.U,m),N.power(recipP.V,n)).chi));
    grid.push({m,n,chi});
  }
  cases.push({q:T.q,p:T.p,readings,oriented_signs:{epsilonQ:sign(W.wq),epsilonP:sign(W.wp)},moments:W,recovered:rec,heldout,grid});
}
for(const q of ['1/3','1/2','1','2','3'])for(const p of ['1/3','1/2','1','2','3'])runCase(q,p);
const example=cases.find(x=>x.q.eq('1/2')&&x.p.eq('1/3'));
check('worked_example_exact_fractions',example.readings[0].chi.eq('144/625')&&example.readings[1].chi.eq('5184/15625')&&example.readings[2].chi.eq('9216/15625')&&example.heldout.chi.eq('331776/390625')&&example.moments.wq.eq('24/25')&&example.moments.wp.eq('24/25'));
const branches=[['1/2','1/3'],['2','1/3'],['1/2','3'],['2','3']].map(([q,p])=>{
  const T=transports(q,p),W=moments(T.U,T.V);return {q:f(q),p:f(p),epsilonQ:sign(W.wq),epsilonP:sign(W.wp),chis:[loop(T.U,T.V).chi,loop(N.power(T.U,2),T.V).chi,loop(T.U,N.power(T.V,2)).chi]};
});
control('three_scalar_readings_leave_four_positive_branches',branches.every(t=>t.chis.every((x,i)=>x.eq(example.readings[i].chi))));
check('oriented_sign_pair_distinguishes_four_branches',new Set(branches.map(t=>t.epsilonQ+','+t.epsilonP)).size===4);
function rejects(fn){try{fn();return false;}catch{return true;}}
control('inconsistent_amplitude_product_is_rejected',rejects(()=>decode(['1/4','1/4','1/4'],1,1)));
control('invalid_amplitude_is_rejected',rejects(()=>decode(['1/100','1','1'],1,1)));
control('zero_sign_off_balance_is_rejected',rejects(()=>decode(example.readings.map(r=>r.chi),0,1)));
control('nonzero_sign_at_balance_is_rejected',rejects(()=>decode([1,0,0],1,0)));
control('zero_base_response_is_outside_decoder_domain',rejects(()=>decode([0,0,0],0,0)));
control('irrational_float_fallback_is_forbidden',rejects(()=>sqrtExact(2)));
const T=transports('1/2','1/3');
control('linear_coordinate_doubling_is_not_operator_repetition',!N.equal(N.power(T.U,2),N.cayley(R,1)));
check('fractional_coordinate_doubling_matches_operator_word',N.equal(N.power(T.U,2),N.cayley(R,'4/3')));
const balanced=transports(1,1),parity=[];
for(let m=1;m<=4;m++)for(let n=1;n<=4;n++){
  const t=loop(N.power(balanced.U,m),N.power(balanced.V,n)),odd=(m%2===1&&n%2===1);
  check('balanced_cell_parity:'+m+','+n,t.chi.eq(odd?1:0)&&N.equal(t.H,N.scale(I,odd?-1:1)));parity.push({m,n,chi:t.chi});
}
control('cayley_chart_pole_is_not_operator_divergence',N.equal(N.power(balanced.U,2),N.scale(I,-1)));
const phaseQ=new Cut('3/5','4/5'),phaseP=new Cut('5/13','12/13'),phaseU=N.scale(T.U,phaseQ),phaseV=N.scale(T.V,phaseP),wm=moments(T.U,T.V),wphase=moments(phaseU,phaseV);
check('independent_global_phase_invariance',N.equal(loop(phaseU,phaseV).H,loop(T.U,T.V).H)&&wphase.wq.eq(wm.wq)&&wphase.wp.eq(wm.wp));
const alias=transports(-2,-3),aliasW=moments(alias.U,alias.V);
control('positive_chart_recovery_does_not_fix_central_sign',N.equal(alias.U,N.scale(T.U,-1))&&N.equal(alias.V,N.scale(T.V,-1))&&aliasW.wq.eq(wm.wq)&&aliasW.wp.eq(wm.wp)&&example.grid.every(({m,n,chi})=>chi.eq(loop(N.power(alias.U,m),N.power(alias.V,n)).chi)));
const frame=mm(N.cayley(R,'2/3'),N.cayley(J,'3/4')),rotate=A=>mm(adj(frame),A,frame),rotW=moments(rotate(T.U),rotate(T.V),{K:rotate(K),iR:rotate(iR),Z:rotate(Z)});
check('joint_frame_covariance_including_comparators',rotW.wq.eq(wm.wq)&&rotW.wp.eq(wm.wp)&&loop(rotate(T.U),rotate(T.V)).chi.eq(loop(T.U,T.V).chi));
check('positive_orientation_gain_preserves_sign',sign(wm.wq.mul(7))===sign(wm.wq)&&sign(wm.wp.mul('3/2'))===sign(wm.wp));
control('unknown_orientation_offset_can_reverse_branch',sign(wm.wq.sub(2))!==sign(wm.wq));
control('held_out_transport_drift_breaks_prediction',!loop(N.power(N.cayley(R,'3/5'),2),N.power(T.V,2)).chi.eq(example.recovered.predicted_chi22));
control('constant_linear_coordinate_gain_conflicts_with_phase_composition',!f('4/3').div(2).eq('1/2'));

const output={schema:'native-phase-word-reconstruction.v1',status:'PASS_NATIVE_PHASE_WORD_RECONSTRUCTION',
 scope:'Conditional native reconstruction theorem for a two-axis cell. Exact synthetic operator words, not an empirical gravitational result. Continuous phase integration is a written derivation; the executable certifies its first-order algebraic jet.',
 assumptions:['Finite positive base q,p chooses a Cayley chart representative','Known oriented axes R and iota*K; all comparators transform together with a frame change','Repeat the same transports with stable controls; do not replace q by m*q','Normalized root responses use unit edge weights and a shared gain within each bare/effective pair','Orientation detectors have known zero and orientation; unknown positive gains are permitted','The executable decoder requires rational square roots; the theorem uses retained native real-completion roots for general exact data'],
 presentations,certificates,checks,negative_controls:controls,cases,example,branches,balanced_cell_parity:parity,
 formulas:{word_invariant:'chi[m,n]=b_m^2*d_n^2; b_(m+1)=2*a*b_m-b_(m-1); b_0=0,b_1=b',
  amplitude_reconstruction:'u=1-chi21/(4*chi11); v=1-chi12/(4*chi11); require 0<u,v<=1 and chi11=u*v',
  orientation:'wq=tr(Z*U^dagger*K*U)/2=2*a*b; wp=tr(Z*V^dagger*(iota*R)*V)/2=2*c*d; Z=-R*K',
  positive_chart_reconstruction:'a=epsilonQ*sqrt(1-u), b=sqrt(u), q=(1-a)/b; likewise for p',
  prediction:'chi22=chi21*chi12/chi11; chi31=chi11*(3-4*u)^2; chi13=chi11*(3-4*v)^2',
  scalar_ambiguity:'Every integer-repeat invariant is invariant under independent q->1/q and p->1/p',
  additive_phase:'Under differentiable same-axis additive continuation: dq/dx=g*(1+q^2); Phi(q)=2*integral_0^q du/(1+u^2)=kappa*x locally, kappa=2*g',
  retained_aliases:'Present loop and channel readouts determine individual transport phase modulo pi. Retain thetaQ=Phi(q)+pi*mQ and thetaP=Phi(p)+pi*mP; do not silently set mQ=mP=0.',
  coupling_boundary:'Constant phase coupling kappa is not the inherited constant linear Cayley-input factor alpha. A proposed physical adapter and a branch/unwrapping record are additional data.'},
 summary:{symbolic_certificates:certificates.length,serialized_replays:certificates.length,exact_checks:checks.length,negative_controls:controls.length,synthetic_cells:cases.length,integer_word_cases:cases.length*16,balanced_parity_cases:parity.length}};
const serialized=JSON.stringify(output,null,2)+'\n',out=path.join(root,'PHASE_WORD_RESULT.json');
if(process.argv.includes('--check'))assert.equal(fs.readFileSync(out,'utf8'),serialized,'Recorded result differs from native replay');else fs.writeFileSync(out,serialized);
console.log(JSON.stringify({status:output.status,...output.summary,example:output.example,branches:output.branches},null,2));
