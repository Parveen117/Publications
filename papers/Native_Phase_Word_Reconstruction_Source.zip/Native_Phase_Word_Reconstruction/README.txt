NATIVE PHASE-WORD RECONSTRUCTION -- version 0.6 -- 14 October 2026

Read Native_Phase_Word_Reconstruction.pdf first.

Run from this directory:
    python3.12 verify.py

Python 3.12 validates files and orchestrates Node. All mathematical arithmetic
uses the unchanged pinned native cut engine and rewrite compiler, nested in:
    parent/parent/parent/parent/baseline/native/core/

Main deliverables:
    Native_Phase_Word_Reconstruction.tex   Written proofs and explicit scope
    verify_phase_words.cjs                Exact native verification/decoder
    PHASE_WORD_RESULT.json                Full results and replayable certificates
    PHASE_PROTOCOL.json                   Input/output contract and boundaries
    MANIFEST.json                         SHA-256 file inventory

The parent/ directory contains the unchanged version 0.5 clock-relation packet,
including its nested predecessors. Their mathematics is credited as input.
The inherited repository anchor is e8e3089745bf7dc0532d01c62a5f660f5658c6f0.
No remote or local repository files were edited in this development.

NEW CONDITIONAL RESULT
Three normalized root responses for (U,V), (U^2,V), (U,V^2) recover b^2,d^2.
Two oriented channel signs select positive finite Cayley coordinates q,p.
The unused fourth response is chi22=chi21*chi12/chi11. Recurrence predicts
all integer-repeat scalar words, which alone cannot break reciprocal branches.

The sign readouts and loop words remain insensitive to individual global
phases. The decoder chooses a positive chart representative; it does not
measure the phase-unwrapping integers. Physical calibration remains conditional
on a source-to-transport dictionary and a retained branch record.

The additive phase continuation law is a written analytic derivation with a
native first-order jet certificate. The verifier does not numerically integrate
or invert the phase integral. General exact roots are retained in the theorem's
native real completion; the executable admits only perfect rational roots and
refuses float approximations.

VERIFIED
13 polynomial certificates; 13 serialized replays; 952 checks; 13 negative
controls; 25 synthetic cells; 400 integer-word cases; 16 balanced parity cases.
Checks are not independent physical experiments or external certification.

Build PDF if TeX and Latin Modern fonts are installed:
    pdflatex -interaction=nonstopmode -halt-on-error Native_Phase_Word_Reconstruction.tex
    pdflatex -interaction=nonstopmode -halt-on-error Native_Phase_Word_Reconstruction.tex
Rebuilding alters PDF metadata/bytes; the included manifest refers to the
delivered PDF. Verify the original packet before rebuilding its artifacts.
